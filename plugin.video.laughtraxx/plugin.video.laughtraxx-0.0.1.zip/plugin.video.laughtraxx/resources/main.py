
<dir>
        <title>THE ADDAMS FAMILY</title>
        <meta>
                <content>tvshow</content>
                <imdb></imdb>
                <tvdb></tvdb>
                <tvshowtitle></tvshowtitle>
                <year></year>
        </meta>
        <link>https://raw.githubusercontent.com/Doggmatic71/doggmatic71/master/plugin.video.laughtraxx/resources/addamsseasons.xml</link>
        <animated_thumbnail></animated_thumbnail>
	    <thumbnail>http://www.neatorama.com/wp-content/uploads/2011/05/5748968112_2499387ffb.jpg</thumbnail>
	    <fanart>http://s1.dmcdn.net/ImrVc/1280x720-w-R.jpg</fanart>
</dir>

<dir>
        <title>THE ANDY GRIFFITH SHOW</title>
        <meta>
                <content>tvshow</content>
                <imdb></imdb>
                <tvdb></tvdb>
                <tvshowtitle></tvshowtitle>
                <year></year>
        </meta>
        <link>https://raw.githubusercontent.com/Doggmatic71/doggmatic71/master/plugin.video.laughtraxx/resources/griffithseasons.xml</link>
        <animated_thumbnail></animated_thumbnail>
	    <thumbnail>http://images.zap2it.com/assets/p183943_b_h3_aa/the-andy-griffith-show.jpg</thumbnail>
	    <fanart>http://s1.dmcdn.net/P6AaR/1280x720-Civ.jpg</fanart>
</dir>

<dir>
        <title>THE BENNY HILL SHOW</title>
        <meta>
                <content>tvshow</content>
                <imdb></imdb>
                <tvdb></tvdb>
                <tvshowtitle></tvshowtitle>
                <year></year>
        </meta>
        <link>https://raw.githubusercontent.com/Doggmatic71/doggmatic71/master/plugin.video.laughtraxx/resources/bennyseasons.xml</link>
        <animated_thumbnail></animated_thumbnail>
	    <thumbnail>http://iv1.lisimg.com/image/1894349/380full-the-benny-hill-show-poster.jpg</thumbnail>
	    <fanart>https://www.theplace2.ru/archive/benny_hill/img/Benny_Hill_2_05.jpg</fanart>
</dir>

<dir>
        <title>THE BEVERLY HILLBILLIES</title>
        <meta>
                <content>tvshow</content>
                <imdb></imdb>
                <tvdb></tvdb>
                <tvshowtitle></tvshowtitle>
                <year></year>
        </meta>
        <link>https://raw.githubusercontent.com/Doggmatic71/doggmatic71/master/plugin.video.laughtraxx/resources/beverlyseasons.xml</link>
        <animated_thumbnail></animated_thumbnail>
	    <thumbnail>https://upload.wikimedia.org/wikipedia/en/thumb/4/4e/The_Beverly_Hillbillies.jpg/250px-The_Beverly_Hillbillies.jpg</thumbnail>
	    <fanart>https://media1.s-nbcnews.com/i/newscms/2017_32/1274364/beverly-hillbillies-today-170809-tease_8504650e1b34d53927ce5d5f1523b574.jpg</fanart>
</dir>

<dir>
        <title>BEWITCHED</title>
        <meta>
                <content>tvshow</content>
                <imdb></imdb>
                <tvdb></tvdb>
                <tvshowtitle></tvshowtitle>
                <year></year>
        </meta>
        <link>https://raw.githubusercontent.com/Doggmatic71/doggmatic71/master/plugin.video.laughtraxx/resources/bewitchedseasons.xml</link>
        <animated_thumbnail></animated_thumbnail>
	    <thumbnail>https://upload.wikimedia.org/wikipedia/en/9/9e/Bewitched_color_title_card.jpg</thumbnail>
	    <fanart>https://cdn4.famefocus.com/wp-content/uploads/2016/04/bewitched-1024x578.jpg</fanart>
</dir>

<dir>
        <title>BONANZA</title>
        <meta>
                <content>tvshow</content>
                <imdb></imdb>
                <tvdb></tvdb>
                <tvshowtitle></tvshowtitle>
                <year></year>
        </meta>
        <link>https://raw.githubusercontent.com/Doggmatic71/maddogg/master/plugin.video.laughtraxx/plugin.video.laughtraxx/resources/bonanzaseasons.xml</link>
        <animated_thumbnail></animated_thumbnail>
	    <thumbnail>http://static.tvgcdn.net/feed/1/26/thumbs/11763026_1300x1733.jpg</thumbnail>
	    <fanart>http://static.worldemand.com/wp-content/uploads/2017/10/26133342/There-were-no-lead-characters.jpg</fanart>
</dir>

<dir>
        <title>F TROOP</title>
        <meta>
                <content>tvshow</content>
                <imdb></imdb>
                <tvdb></tvdb>
                <tvshowtitle></tvshowtitle>
                <year></year>
        </meta>
        <link>https://raw.githubusercontent.com/Doggmatic71/doggmatic71/master/plugin.video.laughtraxx/resources/ftroopseasons.xml</link>
        <animated_thumbnail></animated_thumbnail>
	    <thumbnail>http://www.tvweek.com/wp-content/uploads/2016/09/f-troop.jpg</thumbnail>
	    <fanart>https://metvcdn.metv.com/DfRtB-1452273872-96-lists-ftroop_cast_main_1200.jpg</fanart>
</dir>

<dir>
        <title>GET SMART</title>
        <meta>
                <content>tvshow</content>
                <imdb></imdb>
                <tvdb></tvdb>
                <tvshowtitle></tvshowtitle>
                <year></year>
        </meta>
        <link>https://raw.githubusercontent.com/Doggmatic71/doggmatic71/master/plugin.video.laughtraxx/resources/smartseasons.xml</link>
        <animated_thumbnail></animated_thumbnail>
	    <thumbnail>http://www.memorabletv.com/wp-content/uploads/2017/06/get-smart.jpg</thumbnail>
	    <fanart>https://peopledotcom.files.wordpress.com/2017/01/dick-gautier.jpg?w=2000</fanart>
</dir>

<dir>
        <title>GILLIGAN'S ISLAND</title>
        <meta>
                <content>tvshow</content>
                <imdb></imdb>
                <tvdb></tvdb>
                <tvshowtitle></tvshowtitle>
                <year></year>
        </meta>
        <link>https://raw.githubusercontent.com/Doggmatic71/doggmatic71/master/plugin.video.laughtraxx/resources/gilliganseasons.xml</link>
        <animated_thumbnail></animated_thumbnail>
	    <thumbnail>https://images-na.ssl-images-amazon.com/images/M/MV5BMjM1Mjg3NzU4M15BMl5BanBnXkFtZTgwNzE3ODMyMTE@._V1_UX182_CR0,0,182,268_AL_.jpg</thumbnail>
	    <fanart>http://vignette1.wikia.nocookie.net/gilligan5935/images/a/a4/00gilligans-island.jpg/revision/latest?cb=20170301214154</fanart>
</dir>

<dir>
        <title>GOMER PYLE</title>
        <meta>
                <content>tvshow</content>
                <imdb></imdb>
                <tvdb></tvdb>
                <tvshowtitle></tvshowtitle>
                <year></year>
        </meta>
        <link>https://raw.githubusercontent.com/Doggmatic71/doggmatic71/master/plugin.video.laughtraxx/resources/gomerseasons.xml</link>
        <animated_thumbnail></animated_thumbnail>
	    <thumbnail>http://epguides.com/GomerPyleUSMC/cast.jpg</thumbnail>
	    <fanart>https://metvcdn.metv.com/pxPun-1464284450-414-lists-gomerpyle_main_1200_everett.jpg</fanart>
</dir>

<dir>
        <title>GREEN ACRES</title>
        <meta>
                <content>tvshow</content>
                <imdb></imdb>
                <tvdb></tvdb>
                <tvshowtitle></tvshowtitle>
                <year></year>
        </meta>
        <link>https://raw.githubusercontent.com/Doggmatic71/doggmatic71/master/plugin.video.laughtraxx/resources/acresseasons.xml</link>
        <animated_thumbnail></animated_thumbnail>
	    <thumbnail>http://www.the60sofficialsite.com/images/Anim_Homepage.gif</thumbnail>
	    <fanart>https://view.vzaar.com/11066980/image</fanart>
</dir>

<dir>
        <title>HOGAN'S HEROES</title>
        <meta>
                <content>tvshow</content>
                <imdb></imdb>
                <tvdb></tvdb>
                <tvshowtitle></tvshowtitle>
                <year></year>
        </meta>
        <link>https://raw.githubusercontent.com/Doggmatic71/doggmatic71/master/plugin.video.laughtraxx/resources/hoganseasons.xml</link>
        <animated_thumbnail></animated_thumbnail>
	    <thumbnail>https://upload.wikimedia.org/wikipedia/en/e/e7/Hogan%27s_Heroes_Title_Card.png</thumbnail>
	    <fanart>https://metvcdn.metv.com/yeNAa-1459970341-306-lists-hogansheroes_1200.jpg</fanart>
</dir>

<dir>
        <title>THE HONEYMOONERS</title>
        <meta>
                <content>tvshow</content>
                <imdb></imdb>
                <tvdb></tvdb>
                <tvshowtitle></tvshowtitle>
                <year></year>
        </meta>
        <link>https://raw.githubusercontent.com/Doggmatic71/doggmatic71/master/plugin.video.laughtraxx/resources/honeymoonersseasons.xml</link>
        <animated_thumbnail></animated_thumbnail>
	    <thumbnail>https://upload.wikimedia.org/wikipedia/en/f/f9/The_Honeymooners_title_screen.png</thumbnail>
	    <fanart>https://i.ytimg.com/vi/XxywjOP5xfA/maxresdefault.jpg</fanart>
</dir>

<dir>
        <title>I DREAM OF JEANNIE</title>
        <meta>
                <content>tvshow</content>
                <imdb></imdb>
                <tvdb></tvdb>
                <tvshowtitle></tvshowtitle>
                <year></year>
        </meta>
        <link>https://raw.githubusercontent.com/Doggmatic71/doggmatic71/master/plugin.video.laughtraxx/resources/jeannieseasons.xml</link>
        <animated_thumbnail></animated_thumbnail>
	    <thumbnail>http://images.zap2it.com/assets/p184165_b_h3_aa/i-dream-of-jeannie.jpg</thumbnail>
	    <fanart>https://cdn4.famefocus.com/wp-content/uploads/2016/04/i-dream-of-jeannie-1401808171-1000x600.jpg</fanart>
</dir>

<dir>
        <title>I LOVE LUCY</title>
        <meta>
                <content>tvshow</content>
                <imdb></imdb>
                <tvdb></tvdb>
                <tvshowtitle></tvshowtitle>
                <year></year>
        </meta>
        <link>https://raw.githubusercontent.com/Doggmatic71/doggmatic71/master/plugin.video.laughtraxx/resources/lucyseasons.xml</link>
        <animated_thumbnail></animated_thumbnail>
	    <thumbnail>https://www.thetvdb.com/banners/_cache/fanart/original/70584-5.jpg</thumbnail>
	    <fanart>https://s-i.huffpost.com/gen/1406221/images/o-I-LOVE-LUCY-ANNIVERSARY-2013-facebook.jpg</fanart>
</dir>

<dir>
        <title>In Living Color</title>
        <meta>
                <content>tvshow</content>
                <imdb></imdb>
                <tvdb></tvdb>
                <tvshowtitle></tvshowtitle>
                <year></year>
        </meta>
        <link></link>
        <animated_thumbnail></animated_thumbnail>
        <thumbnail></thumbnail>
        <animated_fanart></animated_fanart>
        <fanart></fanart>
</dir>

<dir>
        <title>LOST IN SPACE</title>
        <meta>
                <content>tvshow</content>
                <imdb></imdb>
                <tvdb></tvdb>
                <tvshowtitle></tvshowtitle>
                <year></year>
        </meta>
        <link>https://raw.githubusercontent.com/Doggmatic71/doggmatic71/master/plugin.video.laughtraxx/resources/lostseasons.xml</link>
        <animated_thumbnail></animated_thumbnail>
	    <thumbnail>https://i.ytimg.com/vi/fKziysUjufA/hqdefault.jpg</thumbnail>
	    <fanart>http://2.bp.blogspot.com/-wAF8S7bhcEs/VmeAbLNJM3I/AAAAAAABq3w/htcxFIFVySQ/s1600/Lost_in_space_Christmas_2.jpg</fanart>
</dir>

<dir>
        <title>THE MARY TYLER MOORE SHOW</title>
        <meta>
                <content>tvshow</content>
                <imdb></imdb>
                <tvdb></tvdb>
                <tvshowtitle></tvshowtitle>
                <year></year>
        </meta>
        <link>https://raw.githubusercontent.com/Doggmatic71/doggmatic71/master/plugin.video.laughtraxx/resources/mtmseasons.xml</link>
        <animated_thumbnail></animated_thumbnail>
	    <thumbnail>https://1cqgxm3l59yi2wwbnn3qy35h-wpengine.netdna-ssl.com/wp-content/uploads/2009/06/mary-tyler-moore-cast-photo.jpg</thumbnail>
	    <fanart>https://hightimes.com/wp-content/uploads/2016/08/EdAsner-MTMShow.jpg</fanart>
</dir>

<dir>
        <title>M*A*S*H</title>
        <meta>
                <content>tvshow</content>
                <imdb></imdb>
                <tvdb></tvdb>
                <tvshowtitle></tvshowtitle>
                <year></year>
        </meta>
        <link>https://raw.githubusercontent.com/Doggmatic71/doggmatic71/master/plugin.video.laughtraxx/resources/mashseasons.xml</link>
        <animated_thumbnail></animated_thumbnail>
	    <thumbnail>http://images1.fanpop.com/images/image_uploads/MASH-m-a-s-h-1186356_500_375.jpg</thumbnail>
	    <fanart>https://tvseriesfinale.com/wp-content/uploads/2015/11/M-A-S-H-m-a-s-h-17473536-1600-1200.jpg</fanart>
</dir>

<dir>
        <title>MCHALE'S NAVY</title>
        <meta>
                <content>tvshow</content>
                <imdb></imdb>
                <tvdb></tvdb>
                <tvshowtitle></tvshowtitle>
                <year></year>
        </meta>
        <link>https://raw.githubusercontent.com/Doggmatic71/doggmatic71/master/plugin.video.laughtraxx/resources/mchaleseasons.xml</link>
        <animated_thumbnail></animated_thumbnail>
	    <thumbnail>http://1.bp.blogspot.com/_GzDSYCqX7vo/TJanUnVu2GI/AAAAAAAABkQ/KS0vq4eMk2U/s1600/McHale%27s+Navy.jpg</thumbnail>
	    <fanart>https://view.vzaar.com/9717478/image</fanart>
</dir>

<dir>
        <title>THE MONKEES</title>
        <meta>
                <content>tvshow</content>
                <imdb></imdb>
                <tvdb></tvdb>
                <tvshowtitle></tvshowtitle>
                <year></year>
        </meta>
        <link>https://raw.githubusercontent.com/Doggmatic71/doggmatic71/master/plugin.video.laughtraxx/resources/monkeesseasons.xml</link>
        <animated_thumbnail></animated_thumbnail>
	    <thumbnail>http://images.zap2it.com/assets/p183941_b_h3_ac/the-monkees.jpg</thumbnail>
	    <fanart>https://static01.nyt.com/images/2012/03/01/arts/JONES1-obit/JONES1-obit-jumbo.jpg</fanart>
</dir>

<dir>
        <title>MONTY PYTHON'S FLYING CIRCUS</title>
        <meta>
                <content>tvshow</content>
                <imdb></imdb>
                <tvdb></tvdb>
                <tvshowtitle></tvshowtitle>
                <year></year>
        </meta>
        <link>https://raw.githubusercontent.com/Doggmatic71/doggmatic71/master/plugin.video.laughtraxx/resources/montyseasons.xml</link>
        <animated_thumbnail></animated_thumbnail>
	    <thumbnail>https://images-na.ssl-images-amazon.com/images/M/MV5BNzY1MDE5OTY4Ml5BMl5BanBnXkFtZTgwOTAyNTQ1NjE@._V1_UX182_CR0,0,182,268_AL_.jpg</thumbnail>
	    <fanart>https://lh3.ggpht.com/SGI9qc7L6lXTwFpKp9hP8dpCSd-8nBBOfw2aoWKV_KJvZ-ILg_BCZuJ3OmIWubRWaT4f=w1264</fanart>
</dir>

<dir>
        <title>MORK AND MINDY</title>
        <meta>
                <content>tvshow</content>
                <imdb></imdb>
                <tvdb></tvdb>
                <tvshowtitle></tvshowtitle>
                <year></year>
        </meta>
        <link>https://raw.githubusercontent.com/Doggmatic71/doggmatic71/master/plugin.video.laughtraxx/resources/morkseasons.xml</link>
        <animated_thumbnail></animated_thumbnail>
	    <thumbnail>http://images.zap2it.com/assets/p184152_b_h3_aa/mork-and-mindy.jpg</thumbnail>
	    <fanart>https://s-i.huffpost.com/gen/1579379/images/o-MORK-AND-MINDY-facebook.jpg</fanart>
</dir>

<dir>
        <title>THE MUNSTERS</title>
        <meta>
                <content>tvshow</content>
                <imdb></imdb>
                <tvdb></tvdb>
                <tvshowtitle></tvshowtitle>
                <year></year>
        </meta>
        <link>https://raw.githubusercontent.com/Doggmatic71/doggmatic71/master/plugin.video.laughtraxx/resources/munstersseasons.xml</link>
        <animated_thumbnail></animated_thumbnail>
	    <thumbnail>http://www.gstatic.com/tv/thumb/tvbanners/184150/p184150_b_v8_ac.jpg</thumbnail>
	    <fanart>http://thehauntedmillnc.com/wp-content/uploads/2017/10/Eddie-Family-2.jpg</fanart>
</dir>

<dir>
        <title>MY FAVORITE MARTIAN</title>
        <meta>
                <content>tvshow</content>
                <imdb></imdb>
                <tvdb></tvdb>
                <tvshowtitle></tvshowtitle>
                <year></year>
        </meta>
        <link>https://raw.githubusercontent.com/Doggmatic71/doggmatic71/master/plugin.video.laughtraxx/resources/martianseasons.xml</link>
		<animated_thumbnail></animated_thumbnail>
	    <thumbnail>http://static.tvtropes.org/pmwiki/pub/images/my_favorite_martian__tv_series_7268.jpg</thumbnail>
	    <fanart>https://ibhuluimcom-a.akamaihd.net/ib.huluim.com/video/60387754?size=1024x576</fanart>
</dir>

<dir>
        <title>MY THREE SONS</title>
        <meta>
                <content>tvshow</content>
                <imdb></imdb>
                <tvdb></tvdb>
                <tvshowtitle></tvshowtitle>
                <year></year>
        </meta>
        <link></link>
        <animated_thumbnail></animated_thumbnail>
	    <thumbnail>http://img.sharetv.com/shows/standard/my_three_sons.jpg</thumbnail>
	    <fanart>https://static01.nyt.com/images/2012/06/29/arts/GRADY1-obit/GRADY1-obit-jumbo.jpg</fanart>
</dir>

<dir>
        <title>PETTICOAT JUNCTION</title>
        <meta>
                <content>tvshow</content>
                <imdb></imdb>
                <tvdb></tvdb>
                <tvshowtitle></tvshowtitle>
                <year></year>
        </meta>
        <link>https://raw.githubusercontent.com/Doggmatic71/maddogg/master/plugin.video.laughtraxx/plugin.video.laughtraxx/resources/junctionseasons.xml</link>
        <animated_thumbnail></animated_thumbnail>
	    <thumbnail>https://upload.wikimedia.org/wikipedia/commons/4/4d/Petticoat_Junction_cast_1968.JPG</thumbnail>
	    <fanart>https://cdn1.thr.com/sites/default/files/2016/02/petticoat_junction_mike_minor_still.jpg</fanart>
</dir>

<dir>
        <title>PORRIDGE</title>
        <meta>
                <content>tvshow</content>
                <imdb></imdb>
                <tvdb></tvdb>
                <tvshowtitle></tvshowtitle>
                <year></year>
        </meta>
        <link>https://raw.githubusercontent.com/Doggmatic71/doggmatic71/master/plugin.video.laughtraxx/resources/porridgeseasons.xml</link>
        <animated_thumbnail></animated_thumbnail>
	    <thumbnail>https://i.pinimg.com/736x/77/45/ed/7745ed189b7fd2f17be068c4cda3fe3f--comedy-tv-tv-series.jpg</thumbnail>
	    <fanart>https://res.cloudinary.com/uktv/image/upload/v1385035581/l8hmbuky4hvwhj3cfgdw.jpg</fanart>
</dir>

<dir>
        <title>Sanford and Son</title>
        <meta>
                <content>tvshow</content>
                <imdb></imdb>
                <tvdb></tvdb>
                <tvshowtitle>The Three Stooges</tvshowtitle>
                <year>1972</year>
        </meta>
        <link>https://raw.githubusercontent.com/Doggmatic71/doggmatic71/master/plugin.video.laughtraxx/resources/sanfordseasons.xml</link>
	    <thumbnail>https://www.thetvdb.com/banners/_cache/posters/78193-3.jpg</thumbnail>
	    <fanart>https://www.thetvdb.com/banners/_cache/fanart/original/78193-4.jpg</fanart>
</dir>

<dir>
        <title>THE THREE STOOGES</title>
        <meta>
                <content>tvshow</content>
                <imdb>tt6512916</imdb>
                <tvdb>79173</tvdb>
                <tvshowtitle>The Three Stooges</tvshowtitle>
                <year>1934</year>
        </meta>
        <link>https://raw.githubusercontent.com/Doggmatic71/doggmatic71/master/plugin.video.laughtraxx/resources/3stoogesseasons.xml</link>
	    <thumbnail>http://epguides.com/ThreeStooges/cast.jpg</thumbnail>
	    <fanart>https://localtvkplr.files.wordpress.com/2012/04/the-three-stooges-11.jpg?quality=85&strip=all&w=2000</fanart>
</dir>

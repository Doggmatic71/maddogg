
<dir>
        <title>THE ADDAMS FAMILY</title>
        <meta>
                <content>tvshow</content>
                <imdb></imdb>
                <tvdb></tvdb>
                <tvshowtitle></tvshowtitle>
                <year></year>
        </meta>
        <link>https://raw.githubusercontent.com/Doggmatic71/maddogg/master/plugin.video.laughtraxx/plugin.video.laughtraxx/resources/addamsseasons.xml</link>
        <animated_thumbnail></animated_thumbnail>
	    <thumbnail>http://www.neatorama.com/wp-content/uploads/2011/05/5748968112_2499387ffb.jpg</thumbnail>
	    <fanart>http://s1.dmcdn.net/ImrVc/1280x720-w-R.jpg</fanart>
</dir>

<dir>
        <title>ALL IN THE FAMILY</title>
        <meta>
                <content>tvshow</content>
                <imdb></imdb>
                <tvdb></tvdb>
                <tvshowtitle></tvshowtitle>
                <year></year>
        </meta>
        <link>https://raw.githubusercontent.com/Doggmatic71/maddogg/master/plugin.video.laughtraxx/plugin.video.laughtraxx/resources/familyseasons.xml</link>
        <animated_thumbnail></animated_thumbnail>
	    <thumbnail>https://www.thetvdb.com/banners/_cache/posters/72741-5.jpg</thumbnail>
	    <fanart>https://www.thetvdb.com/banners/_cache/fanart/original/72741-4.jpg</fanart>
</dir>

<dir>
        <title>THE ANDY GRIFFITH SHOW</title>
        <meta>
                <content>tvshow</content>
                <imdb></imdb>
                <tvdb></tvdb>
                <tvshowtitle></tvshowtitle>
                <year></year>
        </meta>
        <link>https://raw.githubusercontent.com/Doggmatic71/maddogg/master/plugin.video.laughtraxx/plugin.video.laughtraxx/resources/griffithseasons.xml</link>
        <animated_thumbnail></animated_thumbnail>
	    <thumbnail>http://images.zap2it.com/assets/p183943_b_h3_aa/the-andy-griffith-show.jpg</thumbnail>
	    <fanart>http://s1.dmcdn.net/P6AaR/1280x720-Civ.jpg</fanart>
</dir>

<dir>
        <title>ARE YOU BEING SERVED?</title>
        <meta>
                <content>tvshow</content>
                <imdb></imdb>
                <tvdb></tvdb>
                <tvshowtitle></tvshowtitle>
                <year></year>
        </meta>
        <link>https://raw.githubusercontent.com/Doggmatic71/maddogg/master/plugin.video.laughtraxx/plugin.video.laughtraxx/resources/servedseasons.xml</link>
        <animated_thumbnail></animated_thumbnail>
	    <thumbnail>https://www.thetvdb.com/banners/_cache/posters/77879-4.jpg</thumbnail>
	    <fanart>https://www.thetvdb.com/banners/_cache/fanart/original/77879-2.jpg</fanart>
</dir>

<dir>
        <title>THE BENNY HILL SHOW</title>
        <meta>
                <content>tvshow</content>
                <imdb></imdb>
                <tvdb></tvdb>
                <tvshowtitle></tvshowtitle>
                <year></year>
        </meta>
        <link>https://raw.githubusercontent.com/Doggmatic71/maddogg/master/plugin.video.laughtraxx/plugin.video.laughtraxx/resources/bennyseasons.xml</link>
        <animated_thumbnail></animated_thumbnail>
	    <thumbnail>http://iv1.lisimg.com/image/1894349/380full-the-benny-hill-show-poster.jpg</thumbnail>
	    <fanart>https://www.theplace2.ru/archive/benny_hill/img/Benny_Hill_2_05.jpg</fanart>
</dir>

<dir>
        <title>THE BEVERLY HILLBILLIES</title>
        <meta>
                <content>tvshow</content>
                <imdb></imdb>
                <tvdb></tvdb>
                <tvshowtitle></tvshowtitle>
                <year></year>
        </meta>
        <link>https://raw.githubusercontent.com/Doggmatic71/maddogg/master/plugin.video.laughtraxx/plugin.video.laughtraxx/resources/beverlyseasons.xml</link>
        <animated_thumbnail></animated_thumbnail>
	    <thumbnail>https://upload.wikimedia.org/wikipedia/en/thumb/4/4e/The_Beverly_Hillbillies.jpg/250px-The_Beverly_Hillbillies.jpg</thumbnail>
	    <fanart>https://media1.s-nbcnews.com/i/newscms/2017_32/1274364/beverly-hillbillies-today-170809-tease_8504650e1b34d53927ce5d5f1523b574.jpg</fanart>
</dir>

<dir>
        <title>BEWITCHED</title>
        <meta>
                <content>tvshow</content>
                <imdb></imdb>
                <tvdb></tvdb>
                <tvshowtitle></tvshowtitle>
                <year></year>
        </meta>
        <link>https://raw.githubusercontent.com/Doggmatic71/maddogg/master/plugin.video.laughtraxx/plugin.video.laughtraxx/resources/bewitchedseasons.xml</link>
        <animated_thumbnail></animated_thumbnail>
	    <thumbnail>https://upload.wikimedia.org/wikipedia/en/9/9e/Bewitched_color_title_card.jpg</thumbnail>
	    <fanart>https://cdn4.famefocus.com/wp-content/uploads/2016/04/bewitched-1024x578.jpg</fanart>
</dir>

<dir>
        <title>BONANZA</title>
        <meta>
                <content>tvshow</content>
                <imdb></imdb>
                <tvdb></tvdb>
                <tvshowtitle></tvshowtitle>
                <year></year>
        </meta>
        <link>https://raw.githubusercontent.com/Doggmatic71/maddogg/master/plugin.video.laughtraxx/plugin.video.laughtraxx/resources/bonanzaseasons.xml</link>
        <animated_thumbnail></animated_thumbnail>
	    <thumbnail>http://static.tvgcdn.net/feed/1/26/thumbs/11763026_1300x1733.jpg</thumbnail>
	    <fanart>http://static.worldemand.com/wp-content/uploads/2017/10/26133342/There-were-no-lead-characters.jpg</fanart>
</dir>

<dir>
        <title>F TROOP</title>
        <meta>
                <content>tvshow</content>
                <imdb></imdb>
                <tvdb></tvdb>
                <tvshowtitle></tvshowtitle>
                <year></year>
        </meta>
        <link>https://raw.githubusercontent.com/Doggmatic71/maddogg/master/plugin.video.laughtraxx/plugin.video.laughtraxx/resources/ftroopseasons.xml</link>
        <animated_thumbnail></animated_thumbnail>
	    <thumbnail>http://www.tvweek.com/wp-content/uploads/2016/09/f-troop.jpg</thumbnail>
	    <fanart>https://metvcdn.metv.com/DfRtB-1452273872-96-lists-ftroop_cast_main_1200.jpg</fanart>
</dir>

<dir>
        <title>FANTASY ISLAND</title>
        <meta>
                <content>tvshow</content>
                <imdb></imdb>
                <tvdb></tvdb>
                <tvshowtitle></tvshowtitle>
                <year></year>
        </meta>
        <link>https://raw.githubusercontent.com/Doggmatic71/maddogg/master/plugin.video.laughtraxx/plugin.video.laughtraxx/resources/fantasyseasons.xml</link>
        <animated_thumbnail></animated_thumbnail>
	    <thumbnail>https://www.thetvdb.com/banners/_cache/posters/77722-3.jpg</thumbnail>
	    <fanart>https://www.thetvdb.com/banners/_cache/fanart/original/77722-1.jpg</fanart>
</dir>

<dir>
        <title>FAWLTY TOWERS</title>
        <meta>
                <content>tvshow</content>
                <imdb></imdb>
                <tvdb></tvdb>
                <tvshowtitle></tvshowtitle>
                <year></year>
        </meta>
        <link>https://raw.githubusercontent.com/Doggmatic71/maddogg/master/plugin.video.laughtraxx/plugin.video.laughtraxx/resources/fawltyseasons.xml</link>
        <animated_thumbnail></animated_thumbnail>
	    <thumbnail>https://www.thetvdb.com/banners/_cache/posters/75932-3.jpg</thumbnail>
	    <fanart>https://www.thetvdb.com/banners/_cache/fanart/original/75932-11.jpg</fanart>
</dir>

<dir>
        <title>GET SMART</title>
        <meta>
                <content>tvshow</content>
                <imdb></imdb>
                <tvdb></tvdb>
                <tvshowtitle></tvshowtitle>
                <year></year>
        </meta>
        <link>https://raw.githubusercontent.com/Doggmatic71/maddogg/master/plugin.video.laughtraxx/plugin.video.laughtraxx/resources/smartseasons.xml</link>
        <animated_thumbnail></animated_thumbnail>
	    <thumbnail>http://www.memorabletv.com/wp-content/uploads/2017/06/get-smart.jpg</thumbnail>
	    <fanart>https://peopledotcom.files.wordpress.com/2017/01/dick-gautier.jpg?w=2000</fanart>
</dir>

<dir>
        <title>GILLIGAN'S ISLAND</title>
        <meta>
                <content>tvshow</content>
                <imdb></imdb>
                <tvdb></tvdb>
                <tvshowtitle></tvshowtitle>
                <year></year>
        </meta>
        <link>https://raw.githubusercontent.com/Doggmatic71/maddogg/master/plugin.video.laughtraxx/plugin.video.laughtraxx/resources/gilliganseasons.xml</link>
        <animated_thumbnail></animated_thumbnail>
	    <thumbnail>https://images-na.ssl-images-amazon.com/images/M/MV5BMjM1Mjg3NzU4M15BMl5BanBnXkFtZTgwNzE3ODMyMTE@._V1_UX182_CR0,0,182,268_AL_.jpg</thumbnail>
	    <fanart>http://vignette1.wikia.nocookie.net/gilligan5935/images/a/a4/00gilligans-island.jpg/revision/latest?cb=20170301214154</fanart>
</dir>

<dir>
        <title>GOMER PYLE</title>
        <meta>
                <content>tvshow</content>
                <imdb></imdb>
                <tvdb></tvdb>
                <tvshowtitle></tvshowtitle>
                <year></year>
        </meta>
        <link>https://raw.githubusercontent.com/Doggmatic71/maddogg/master/plugin.video.laughtraxx/plugin.video.laughtraxx/resources/gomerseasons.xml</link>
        <animated_thumbnail></animated_thumbnail>
	    <thumbnail>http://epguides.com/GomerPyleUSMC/cast.jpg</thumbnail>
	    <fanart>https://metvcdn.metv.com/pxPun-1464284450-414-lists-gomerpyle_main_1200_everett.jpg</fanart>
</dir>

<dir>
        <title>GOOD TIMES</title>
        <meta>
                <content>tvshow</content>
                <imdb></imdb>
                <tvdb></tvdb>
                <tvshowtitle></tvshowtitle>
                <year></year>
        </meta>
        <link>https://raw.githubusercontent.com/Doggmatic71/maddogg/master/plugin.video.laughtraxx/plugin.video.laughtraxx/resources/goodtimesseasons.xml</link>
        <animated_thumbnail></animated_thumbnail>
	    <thumbnail>https://www.thetvdb.com/banners/_cache/posters/77357-1.jpg</thumbnail>
	    <fanart>https://www.thetvdb.com/banners/_cache/fanart/original/77357-3.jpg</fanart>
</dir>

<dir>
        <title>GREEN ACRES</title>
        <meta>
                <content>tvshow</content>
                <imdb></imdb>
                <tvdb></tvdb>
                <tvshowtitle></tvshowtitle>
                <year></year>
        </meta>
        <link>https://raw.githubusercontent.com/Doggmatic71/maddogg/master/plugin.video.laughtraxx/plugin.video.laughtraxx/resources/acresseasons.xml</link>
        <animated_thumbnail></animated_thumbnail>
	    <thumbnail>http://www.the60sofficialsite.com/images/Anim_Homepage.gif</thumbnail>
	    <fanart>https://view.vzaar.com/11066980/image</fanart>
</dir>

<dir>
        <title>HAPPY DAYS</title>
        <meta>
                <content>tvshow</content>
                <imdb></imdb>
                <tvdb></tvdb>
                <tvshowtitle></tvshowtitle>
                <year></year>
        </meta>
        <link>https://raw.githubusercontent.com/Doggmatic71/maddogg/master/plugin.video.laughtraxx/plugin.video.laughtraxx/resources/happydaysseasons.xml</link>
        <animated_thumbnail></animated_thumbnail>
	    <thumbnail>https://www.thetvdb.com/banners/_cache/posters/74475-3.jpg</thumbnail>
	    <fanart>https://www.thetvdb.com/banners/_cache/fanart/original/74475-8.jpg</fanart>
</dir>

<dir>
        <title>HOGAN'S HEROES</title>
        <meta>
                <content>tvshow</content>
                <imdb></imdb>
                <tvdb></tvdb>
                <tvshowtitle></tvshowtitle>
                <year></year>
        </meta>
        <link>https://raw.githubusercontent.com/Doggmatic71/maddogg/master/plugin.video.laughtraxx/plugin.video.laughtraxx/resources/hoganseasons.xml</link>
        <animated_thumbnail></animated_thumbnail>
	    <thumbnail>https://upload.wikimedia.org/wikipedia/en/e/e7/Hogan%27s_Heroes_Title_Card.png</thumbnail>
	    <fanart>https://metvcdn.metv.com/yeNAa-1459970341-306-lists-hogansheroes_1200.jpg</fanart>
</dir>

<dir>
        <title>THE HONEYMOONERS</title>
        <meta>
                <content>tvshow</content>
                <imdb></imdb>
                <tvdb></tvdb>
                <tvshowtitle></tvshowtitle>
                <year></year>
        </meta>
        <link>https://raw.githubusercontent.com/Doggmatic71/maddogg/master/plugin.video.laughtraxx/plugin.video.laughtraxx/resources/honeymoonersseasons.xml</link>
        <animated_thumbnail></animated_thumbnail>
	    <thumbnail>https://upload.wikimedia.org/wikipedia/en/f/f9/The_Honeymooners_title_screen.png</thumbnail>
	    <fanart>https://i.ytimg.com/vi/XxywjOP5xfA/maxresdefault.jpg</fanart>
</dir>

<dir>
        <title>I DREAM OF JEANNIE</title>
        <meta>
                <content>tvshow</content>
                <imdb></imdb>
                <tvdb></tvdb>
                <tvshowtitle></tvshowtitle>
                <year></year>
        </meta>
        <link>https://raw.githubusercontent.com/Doggmatic71/maddogg/master/plugin.video.laughtraxx/plugin.video.laughtraxx/resources/jeannieseasons.xml</link>
        <animated_thumbnail></animated_thumbnail>
	    <thumbnail>http://images.zap2it.com/assets/p184165_b_h3_aa/i-dream-of-jeannie.jpg</thumbnail>
	    <fanart>https://cdn4.famefocus.com/wp-content/uploads/2016/04/i-dream-of-jeannie-1401808171-1000x600.jpg</fanart>
</dir>

<dir>
        <title>I LOVE LUCY</title>
        <meta>
                <content>tvshow</content>
                <imdb></imdb>
                <tvdb></tvdb>
                <tvshowtitle></tvshowtitle>
                <year></year>
        </meta>
        <link>https://raw.githubusercontent.com/Doggmatic71/maddogg/master/plugin.video.laughtraxx/plugin.video.laughtraxx/resources/lucyseasons.xml</link>
        <animated_thumbnail></animated_thumbnail>
	    <thumbnail>https://www.thetvdb.com/banners/_cache/fanart/original/70584-5.jpg</thumbnail>
	    <fanart>https://s-i.huffpost.com/gen/1406221/images/o-I-LOVE-LUCY-ANNIVERSARY-2013-facebook.jpg</fanart>
</dir>

<dir>
        <title>IN LIVING COLOR</title>
        <meta>
                <content>tvshow</content>
                <imdb></imdb>
                <tvdb></tvdb>
                <tvshowtitle></tvshowtitle>
                <year></year>
        </meta>
        <link>https://raw.githubusercontent.com/Doggmatic71/maddogg/master/plugin.video.laughtraxx/plugin.video.laughtraxx/resources/colorseasons.xml</link>
        <animated_thumbnail></animated_thumbnail>
        <thumbnail>https://www.thetvdb.com/banners/_cache/posters/78441-2.jpg</thumbnail>
        <animated_fanart></animated_fanart>
        <fanart>https://www.thetvdb.com/banners/_cache/fanart/original/78441-3.jpg</fanart>
</dir>

<dir>
        <title>THE JEFFERSONS</title>
        <meta>
                <content>tvshow</content>
                <imdb></imdb>
                <tvdb></tvdb>
                <tvshowtitle></tvshowtitle>
                <year></year>
        </meta>
        <link>https://raw.githubusercontent.com/Doggmatic71/maddogg/master/plugin.video.laughtraxx/plugin.video.laughtraxx/resources/jeffersonsseasons.xml</link>
        <animated_thumbnail></animated_thumbnail>
        <thumbnail>https://www.thetvdb.com/banners/_cache/posters/77792-3.jpg</thumbnail>
        <animated_fanart></animated_fanart>
        <fanart>https://www.thetvdb.com/banners/_cache/fanart/original/77792-4.jpg</fanart>
</dir>

<dir>
        <title>LAVERNE & SHIRLEY</title>
        <meta>
                <content>tvshow</content>
                <imdb></imdb>
                <tvdb></tvdb>
                <tvshowtitle></tvshowtitle>
                <year></year>
        </meta>
        <link>https://raw.githubusercontent.com/Doggmatic71/maddogg/master/plugin.video.laughtraxx/plugin.video.laughtraxx/resources/laverneseasons.xml</link>
        <animated_thumbnail></animated_thumbnail>
        <thumbnail>https://www.thetvdb.com/banners/_cache/posters/78017-1.jpg</thumbnail>
        <animated_fanart></animated_fanart>
        <fanart>https://www.thetvdb.com/banners/_cache/fanart/original/78017-1.jpg</fanart>
</dir>

<dir>
        <title>LOST IN SPACE</title>
        <meta>
                <content>tvshow</content>
                <imdb></imdb>
                <tvdb></tvdb>
                <tvshowtitle></tvshowtitle>
                <year></year>
        </meta>
        <link>https://raw.githubusercontent.com/Doggmatic71/maddogg/master/plugin.video.laughtraxx/plugin.video.laughtraxx/resources/lostseasons.xml</link>
        <animated_thumbnail></animated_thumbnail>
	    <thumbnail>https://i.ytimg.com/vi/fKziysUjufA/hqdefault.jpg</thumbnail>
	    <fanart>http://2.bp.blogspot.com/-wAF8S7bhcEs/VmeAbLNJM3I/AAAAAAABq3w/htcxFIFVySQ/s1600/Lost_in_space_Christmas_2.jpg</fanart>
</dir>

<dir>
        <title>THE MARY TYLER MOORE SHOW</title>
        <meta>
                <content>tvshow</content>
                <imdb></imdb>
                <tvdb></tvdb>
                <tvshowtitle></tvshowtitle>
                <year></year>
        </meta>
        <link>https://raw.githubusercontent.com/Doggmatic71/maddogg/master/plugin.video.laughtraxx/plugin.video.laughtraxx/resources/mtmseasons.xml</link>
        <animated_thumbnail></animated_thumbnail>
	    <thumbnail>https://1cqgxm3l59yi2wwbnn3qy35h-wpengine.netdna-ssl.com/wp-content/uploads/2009/06/mary-tyler-moore-cast-photo.jpg</thumbnail>
	    <fanart>https://hightimes.com/wp-content/uploads/2016/08/EdAsner-MTMShow.jpg</fanart>
</dir>

<dir>
        <title>M*A*S*H</title>
        <meta>
                <content>tvshow</content>
                <imdb></imdb>
                <tvdb></tvdb>
                <tvshowtitle></tvshowtitle>
                <year></year>
        </meta>
        <link>https://raw.githubusercontent.com/Doggmatic71/maddogg/master/plugin.video.laughtraxx/plugin.video.laughtraxx/resources/mashseasons.xml</link>
        <animated_thumbnail></animated_thumbnail>
	    <thumbnail>http://images1.fanpop.com/images/image_uploads/MASH-m-a-s-h-1186356_500_375.jpg</thumbnail>
	    <fanart>https://tvseriesfinale.com/wp-content/uploads/2015/11/M-A-S-H-m-a-s-h-17473536-1600-1200.jpg</fanart>
</dir>

<dir>
        <title>MCHALE'S NAVY</title>
        <meta>
                <content>tvshow</content>
                <imdb></imdb>
                <tvdb></tvdb>
                <tvshowtitle></tvshowtitle>
                <year></year>
        </meta>
        <link>https://raw.githubusercontent.com/Doggmatic71/maddogg/master/plugin.video.laughtraxx/plugin.video.laughtraxx/resources/mchaleseasons.xml</link>
        <animated_thumbnail></animated_thumbnail>
	    <thumbnail>http://1.bp.blogspot.com/_GzDSYCqX7vo/TJanUnVu2GI/AAAAAAAABkQ/KS0vq4eMk2U/s1600/McHale%27s+Navy.jpg</thumbnail>
	    <fanart>https://view.vzaar.com/9717478/image</fanart>
</dir>

<dir>
        <title>THE MONKEES</title>
        <meta>
                <content>tvshow</content>
                <imdb></imdb>
                <tvdb></tvdb>
                <tvshowtitle></tvshowtitle>
                <year></year>
        </meta>
        <link>https://raw.githubusercontent.com/Doggmatic71/maddogg/master/plugin.video.laughtraxx/plugin.video.laughtraxx/resources/monkeesseasons.xml</link>
        <animated_thumbnail></animated_thumbnail>
	    <thumbnail>http://images.zap2it.com/assets/p183941_b_h3_ac/the-monkees.jpg</thumbnail>
	    <fanart>https://static01.nyt.com/images/2012/03/01/arts/JONES1-obit/JONES1-obit-jumbo.jpg</fanart>
</dir>

<dir>
        <title>MONTY PYTHON'S FLYING CIRCUS</title>
        <meta>
                <content>tvshow</content>
                <imdb></imdb>
                <tvdb></tvdb>
                <tvshowtitle></tvshowtitle>
                <year></year>
        </meta>
        <link>https://raw.githubusercontent.com/Doggmatic71/maddogg/master/plugin.video.laughtraxx/plugin.video.laughtraxx/resources/montyseasons.xml</link>
        <animated_thumbnail></animated_thumbnail>
	    <thumbnail>https://images-na.ssl-images-amazon.com/images/M/MV5BNzY1MDE5OTY4Ml5BMl5BanBnXkFtZTgwOTAyNTQ1NjE@._V1_UX182_CR0,0,182,268_AL_.jpg</thumbnail>
	    <fanart>https://lh3.ggpht.com/SGI9qc7L6lXTwFpKp9hP8dpCSd-8nBBOfw2aoWKV_KJvZ-ILg_BCZuJ3OmIWubRWaT4f=w1264</fanart>
</dir>

<dir>
        <title>MORK AND MINDY</title>
        <meta>
                <content>tvshow</content>
                <imdb></imdb>
                <tvdb></tvdb>
                <tvshowtitle></tvshowtitle>
                <year></year>
        </meta>
        <link>https://raw.githubusercontent.com/Doggmatic71/maddogg/master/plugin.video.laughtraxx/plugin.video.laughtraxx/resources/morkseasons.xml</link>
        <animated_thumbnail></animated_thumbnail>
	    <thumbnail>http://images.zap2it.com/assets/p184152_b_h3_aa/mork-and-mindy.jpg</thumbnail>
	    <fanart>https://s-i.huffpost.com/gen/1579379/images/o-MORK-AND-MINDY-facebook.jpg</fanart>
</dir>

<dir>
        <title>THE MUNSTERS</title>
        <meta>
                <content>tvshow</content>
                <imdb></imdb>
                <tvdb></tvdb>
                <tvshowtitle></tvshowtitle>
                <year></year>
        </meta>
        <link>https://raw.githubusercontent.com/Doggmatic71/maddogg/master/plugin.video.laughtraxx/plugin.video.laughtraxx/resources/munstersseasons.xml</link>
        <animated_thumbnail></animated_thumbnail>
	    <thumbnail>http://www.gstatic.com/tv/thumb/tvbanners/184150/p184150_b_v8_ac.jpg</thumbnail>
	    <fanart>http://thehauntedmillnc.com/wp-content/uploads/2017/10/Eddie-Family-2.jpg</fanart>
</dir>

<dir>
        <title>MY FAVORITE MARTIAN</title>
        <meta>
                <content>tvshow</content>
                <imdb></imdb>
                <tvdb></tvdb>
                <tvshowtitle></tvshowtitle>
                <year></year>
        </meta>
        <link>https://raw.githubusercontent.com/Doggmatic71/maddogg/master/plugin.video.laughtraxx/plugin.video.laughtraxx/resources/martianseasons.xml</link>
		<animated_thumbnail></animated_thumbnail>
	    <thumbnail>http://static.tvtropes.org/pmwiki/pub/images/my_favorite_martian__tv_series_7268.jpg</thumbnail>
	    <fanart>https://ibhuluimcom-a.akamaihd.net/ib.huluim.com/video/60387754?size=1024x576</fanart>
</dir>

<dir>
        <title>MY THREE SONS</title>
        <meta>
                <content>tvshow</content>
                <imdb></imdb>
                <tvdb></tvdb>
                <tvshowtitle></tvshowtitle>
                <year></year>
        </meta>
        <link>https://raw.githubusercontent.com/Doggmatic71/maddogg/master/plugin.video.laughtraxx/plugin.video.laughtraxx/resources/sonsseasons.xml</link>
        <animated_thumbnail></animated_thumbnail>
	    <thumbnail>http://img.sharetv.com/shows/standard/my_three_sons.jpg</thumbnail>
	    <fanart>https://static01.nyt.com/images/2012/06/29/arts/GRADY1-obit/GRADY1-obit-jumbo.jpg</fanart>
</dir>

<dir>
        <title>PETTICOAT JUNCTION</title>
        <meta>
                <content>tvshow</content>
                <imdb></imdb>
                <tvdb></tvdb>
                <tvshowtitle></tvshowtitle>
                <year></year>
        </meta>
        <link>https://raw.githubusercontent.com/Doggmatic71/maddogg/master/plugin.video.laughtraxx/plugin.video.laughtraxx/resources/junctionseasons.xml</link>
        <animated_thumbnail></animated_thumbnail>
	    <thumbnail>https://upload.wikimedia.org/wikipedia/commons/4/4d/Petticoat_Junction_cast_1968.JPG</thumbnail>
	    <fanart>https://cdn1.thr.com/sites/default/files/2016/02/petticoat_junction_mike_minor_still.jpg</fanart>
</dir>

<dir>
        <title>PORRIDGE</title>
        <meta>
                <content>tvshow</content>
                <imdb></imdb>
                <tvdb></tvdb>
                <tvshowtitle></tvshowtitle>
                <year></year>
        </meta>
        <link>https://raw.githubusercontent.com/Doggmatic71/maddogg/master/plugin.video.laughtraxx/plugin.video.laughtraxx/resources/porridgeseasons.xml</link>
        <animated_thumbnail></animated_thumbnail>
	    <thumbnail>https://i.pinimg.com/736x/77/45/ed/7745ed189b7fd2f17be068c4cda3fe3f--comedy-tv-tv-series.jpg</thumbnail>
	    <fanart>https://res.cloudinary.com/uktv/image/upload/v1385035581/l8hmbuky4hvwhj3cfgdw.jpg</fanart>
</dir>

<dir>
        <title>Sanford and Son</title>
        <meta>
                <content>tvshow</content>
                <imdb></imdb>
                <tvdb></tvdb>
                <tvshowtitle>The Three Stooges</tvshowtitle>
                <year></year>
        </meta>
        <link>https://raw.githubusercontent.com/Doggmatic71/maddogg/master/plugin.video.laughtraxx/plugin.video.laughtraxx/resources/sanfordseasons.xml</link>
	    <thumbnail>https://www.thetvdb.com/banners/_cache/posters/78193-3.jpg</thumbnail>
	    <fanart>https://www.thetvdb.com/banners/_cache/fanart/original/78193-4.jpg</fanart>
</dir>

<dir>
        <title>THE THREE STOOGES</title>
        <meta>
                <content>tvshow</content>
                <imdb></imdb>
                <tvdb></tvdb>
                <tvshowtitle>The Three Stooges</tvshowtitle>
                <year></year>
        </meta>
        <link>https://raw.githubusercontent.com/Doggmatic71/maddogg/master/plugin.video.laughtraxx/plugin.video.laughtraxx/resources/3stoogesseasons.xml</link>
	    <thumbnail>http://epguides.com/ThreeStooges/cast.jpg</thumbnail>
	    <fanart>https://localtvkplr.files.wordpress.com/2012/04/the-three-stooges-11.jpg?quality=85&strip=all&w=2000</fanart>
</dir>

<dir>
        <title>THREES COMPANY</title>
        <meta>
                <content>tvshow</content>
                <imdb></imdb>
                <tvdb></tvdb>
                <tvshowtitle></tvshowtitle>
                <year></year>
        </meta>
        <link>https://raw.githubusercontent.com/Doggmatic71/maddogg/master/plugin.video.laughtraxx/plugin.video.laughtraxx/resources/threesseasons.xml</link>
	    <thumbnail>https://www.thetvdb.com/banners/_cache/posters/77505-5.jpg</thumbnail>
	    <fanart>https://www.thetvdb.com/banners/_cache/fanart/original/77505-4.jpg</fanart>
</dir>

<dir>
        <title>WELCOME BACK, KOTTER</title>
        <meta>
                <content>tvshow</content>
                <imdb></imdb>
                <tvdb></tvdb>
                <tvshowtitle></tvshowtitle>
                <year></year>
        </meta>
        <link>https://raw.githubusercontent.com/Doggmatic71/maddogg/master/plugin.video.laughtraxx/plugin.video.laughtraxx/resources/kotterseasons.xml</link>
	    <thumbnail>https://www.thetvdb.com/banners/_cache/posters/78572-2.jpg</thumbnail>
	    <fanart>https://www.thetvdb.com/banners/_cache/fanart/original/78572-7.jpg</fanart>
</dir>

<dir>
        <title>WHAT'S HAPPENING!!</title>
        <meta>
                <content>tvshow</content>
                <imdb></imdb>
                <tvdb></tvdb>
                <tvshowtitle></tvshowtitle>
                <year></year>
        </meta>
        <link>https://raw.githubusercontent.com/Doggmatic71/maddogg/master/plugin.video.laughtraxx/plugin.video.laughtraxx/resources/happeningseasons.xml</link>
	    <thumbnail>https://www.thetvdb.com/banners/_cache/posters/73506-2.jpg</thumbnail>
	    <fanart>https://www.thetvdb.com/banners/_cache/fanart/original/73506-2.jpg</fanart>
</dir>

<dir>
        <title>WKRP IN CINCINNATI</title>
        <meta>
                <content>tvshow</content>
                <imdb></imdb>
                <tvdb></tvdb>
                <tvshowtitle></tvshowtitle>
                <year></year>
        </meta>
        <link>https://raw.githubusercontent.com/Doggmatic71/maddogg/master/plugin.video.laughtraxx/plugin.video.laughtraxx/resources/WKRPseasons.xml</link>
	    <thumbnail>https://www.thetvdb.com/banners/_cache/posters/77761-1.jpg</thumbnail>
	    <fanart>https://www.thetvdb.com/banners/_cache/fanart/original/77761-3.jpg</fanart>
</dir>

<dir>
	<title>[COLORcyan]TRAKT[/COLOR]</title>
        <link>https://raw.githubusercontent.com/Doggmatic71/maddogg/master/plugin.video.laughtraxx/plugin.video.laughtraxx/resources/traktportal.xml</link>
	    <thumbnail>https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQzvSfph49LGl-KZCOTozHJpYlBY0E13z0AKV6i1neSTFVAVQbz</thumbnail>
	    <fanart>https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQOR7jyWqpo_hdJTBbwfDDe4IqFqffz8IuQsVkl3elFkSQlyNFNZA</fanart>
</dir>
	
<dir>
	<title>[COLORred]TESTING AREA[/COLOR]
	<link></link>
	    <thumbnail>data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBw0HEhUPEhMWFQ0XGRoaGBcYFxoaGRgfGhgXGhkYHhgbHiggGiAlHRgXITEtJSkrLi4uFx8zODMtNygtLisBCgoKDg0OGxAQGy0lICUtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLf/AABEIAMgAyAMBEQACEQEDEQH/xAAcAAEAAwADAQEAAAAAAAAAAAAABQYHAQMECAL/xABJEAABAwICBgILDAsBAAMAAAABAAIDBBEFBgcSITFBURMyFiI0QmFzkZOxstIUFzNSU1RVcXSBwdEVIyQ1YnKhoqOz0/CSwuH/xAAbAQEAAgMBAQAAAAAAAAAAAAAABAYBAgMFB//EADsRAAEDAgMEBwUIAQUBAAAAAAABAgMEEQUSIQYTMVEUFjI0QWFxIjNTocEVI0JSgbHR8OEkNWJy8UP/2gAMAwEAAhEDEQA/ANxQBAEAQBAEBC5qzFS5ZgdUzus0bGtHWe7g1o4lES5hTLqeHHs4F1Y6qlpGO+DhiJs1vC+0XPhXhVuOx08m7alzs2BXJqd/Yfjf0rVf/I+0ofWf/gbdF8x2H439K1XlPtJ1mT8g6N5nPYdjn0rVeU+0nWZPyDo/mcdh+N/StV5T7SdZk/IZ6N5nS7K2MMeI/wBKVesQSDc22eHWU1mM56dZ7JZNLeJGciJKkfM7uw/G/pWq8p9pQus//AkdG8x2H439K1XlPtJ1mT8g6N5nPYdjn0rVeU+0nWZPyDo/mcdh2OfStV5T7SdZ0/IOjJzPPWYZmDLlqqKumqHsNzFJcte3iLaxUqkx+OaTI9LGrqdWpdDScl5sps2wdNEdWRthLGT20buR8Gw2PGy984ljQyEAQBAEAQBAEAQBAEBC5pzFS5ZgdUzuswbGtHWe7g1o4lEQwpmOF4ZVZwnGKYgA1jReGE9SJu/WJO87Ad3BVvFsXt9xBqq6aEiGH8TiIzFmepzdO3DcMLmwg9tI0lpdbe4uG1sY/qlFh8NBEtRVaryU0kkdI7Kzgfr3sca+kf8AJN+a59YqH4f7G3R38x72WNfSP+Sb81nrHQ/DX5Do7+Y97LGvpH/JN+adY6H4a/IdGfzHvZY19I/5JvzTrHQ/DX5Doz+Z+veyxr6R/wAk3tLPWKi+GvyHRncz8+9jjX0j/km/NOsVD8NfkOjv5j3ssa+kf8k35rXrDQ/D/YdGfzHvZY19I/5JvzWesdD8NfkOjP5j3ssa+kf8k35p1joV/wDmvyHR38zpwjH67IlSaHES6WkftEhLnao+OwnaW8xvC3qqKDE4d/S6OT+2NWvdG6zibx7Bp8Gmbi2GuBeRdzBtZOw2Ntm+/wD7cueFYq6N3RqjT1Oksd/baaJkzNtNm2ASxbJG2EkZPbRu5HmNhseKtBGRSyIZCAIAgCAIAgCAICFzRmKmyzA6pndZo2NaOs93BrRxKIlzCqZhhWG1WcJ/0niADWMF4YT1Im7y4347B5FW8Wxe3+ng1VSRDEnacQuaMxT5zmGFYaP2bv37g+29xPCMf3JQUMWHx9Kql9r9v8mskjpVyt4GjZRyvT5Wh6KPtpXWMkhFnPP4AcAqviWJy1smZy2ROCEmKJI0JxeTodwgCALNzBCzV8vSENNtU9sOA3hrPCXb/uV5p8Io3USPXiqceRDdI7OTSpDkstiWi6ahaGwQBZMERmbL1NmSEwTDwseOsx3xm/iOK9LDsQko5Ec1dPFDjLEkiGZYFjNTo9nOH1w1qF5ux4uQ0E9dn8O644em21dLDikW/p1s8ise6J2VeBO47gs+DStxbDXAvIu5g2snYbG2xcMKxZY3dHn8NDpLEi+000TJebabNsHTRdrI2wljJ7aN3I+DYbHirSqWIyFkQyEAQBAEAQBAQuaMxU2WYHVNQ6zBsa0dZ7rbGtHEoiXMKtjMMJw2qzhP+k8QAaxovDCerE3eXG/Hdw4Kt4ti9v8ATwaqpJih/E4hs0ZhqM5yjC8OH7L38m4PAO1xPexj+5KChiw+PpVUvtcjSSRZXZGmi5SyvT5Wh6KPtpXWMkhFnPI9AHAKrYniclY+66N8EJMUSMQnF5R3CAIAgCA6zAzW19Ua/O21d0qJEbkRdDXKh2LgbBAEAQBAROZsv02ZITBMPCx46zHfGH5cV6eH4hLRSZ2fqhxliR6GYYFjFXo9nOH1w16F+1rxuaCeuzm2/WHBW2qpIcUh38Gj0IjHrEuVxPY9g1Rg0zcWw1wLyLuYNrJ2Hbw3lcMKxZY3dHn0OksSKmZpomS82U2boOniNniwkjJ7aN3I+DYbHirSpGRSyIZCAIAgCAhc05ipcswOqZ3WaOq0dZ54NaOaIlzCmYYVhtVnCcYpiFmMaLwwnqRN36xJ47Afuuq1i2L2+4p+KkiGL8TiFzPmGoznMMKw4fsvfv3B4G9zjwjH9yzQ0MeHxLVVS+1+3+TWSR0y5WmjZRyvT5Wh6KPbKbGSQixeR6GjgFV8TxOStlu7gnBCTFGjEJxeSp3CAIAgCAIAgCAIAgCAIAsmCJzNl+mzJCYJhzLHgdsx3xm/lxXpYdiMlHJmZw8UOUkSPSymY4HjFXo9nOH1w16F+1rhewBPXZ/D8YcFbqqlixSBJ6dbPIbHuiXK7gTmPYNPg0zcWwxwLyLvYNrJ2Hbw37lGwjFljXo9Rx4eh1ljzJmaaNkvNlNmuDpYzqytsJYye2jdyPg32PFWpUsRkUsV0MnKAICFzTmKlyzA6oqHWaOq0dZ7uDWjiURLmFUzHCsNqs4TjE8Qs1jBeGE9SJu/WJO87AfuVbxbF7fcQaqpIhh0zuIXM2YqjOcowrDgfcvfv3B4vtc48Ix/clDQRYfGtVVL7XghrJI6VcrDRco5Xp8rQ9FHtlNjJIRZzyPQ0cAqxieJy1smZdE8EJMUaMQnF5B3CAIAgCAIAgCAIAgCAIAgCALJgicy5fp8yQmCYeFjx1mO+M38uK9HD8Qko5c7P1TmcpY0ehmOB4zV6PZzh9aC6hdta8Xs0X67P4eY4em3VdLFikKVFOvtp/bERj3ROs7gTuPYLPg0zcWw1wL7XewbWTsNjbZvuuGFYqsbuj1Gh0kiRfaaaJkvNtNm2Dpou1e2wkjJ7ZjuR5jfY8VaeBGQsiGSFzPmKmyzA6pndZo2Nb3z3cGtHEoiXMGY4ThtVnCoGJ4gA1jReGE9SJu8k347Bt8CrWL4vZdxBqvDQkRRficQmZ8xVGc5hhWHD9m79+4SAb3OPexj+5ZoKCOghWqqu1+3+TV8iyLlbwNGyjlenytD0UfbSusZJCLOeR6AOAVXxPFJK2S69lOCEmKJGITi8k7hAEAQBAEAQBAEAQBAEAQBAEAQBAROZsvU2ZITTzDmWPHWY74zfy4r08PxCSjlzt4eKHGSNHoZjgeM1ejuc4fWjWoXG7Hi9mgnrs/hvvHBW2qpIcUhSog0chEY90TrO4E7j2Cz4NM3FsNcNci7mDaydp222b1wwnFnRr0eo08DpLEi+000TJebabNsHTRbHtsJYye2jdyPg2Gx42VqVCMimfQUL83YnUTVTtdlNM+KGO3atDSLu8JOzyKvY7iL6dqRx8V8TtBHm1UhM2Y9U5wm/ROHtPucEiR+0a2qbOLj3sYPlXOgoYqCPpVSt3f35iWRZHZWmh5SyxT5Zh6KPtpTYySEWLyPQOQVXxPEn1squdoicEJMUaRoTi8k7hAEAQBAEAQBAEAQBAEAQBAEAQBAEAWQROZsv02ZITBMPCx46zHfGH5cV6OHV8lHLnbw8UOMkSPSymY4FjFXo9nOH1w1qF+1rhchoJ67ObfjN4K3VVJDikO/g7aESN7onZXcCZzRQHKlXDiVK/Ue+RjJGW7WRr3AG4WmAYhJLeB/gbTsRPaQlsjd2Yj9sl/BQ9p/es9Pqb03BSsaHe76/wCp3+9ykbSdzj9foa0/bU1xUYnBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEBkWnzrUf8s/phV52U9zJ6/RTz6vihYdKPwdP46D1wouzve3nWo7CHfkbuzEftkv4Lbaf3rPT6mKbgpWdDvd9f9Tv97lJ2jS9HH6/Q0p+2prmqeSpGR3InXQaruSZF5GEcg1TyTIvIzdAGlYyLyF0GqeSzkdyUXQap5JkXkMyHC1sDzVNfT0ptJLGx3Jz2tPkJUqKjnkS7GqposjUO2CZlQLsc1zebSCPKFykgfGtnpY2RyLwOwDktEaq8DNznVPJMi8hdBqnkmReQzIC1YyO5C6AjVWVY5OKC4DXckyO5GMyHC1sZOQERqrwCqiHCK2wuFsjHLogVbHjOK0mtqdNFr8ukZfyXUpKCoVM2RbGu8bzPYPAojmq3RTa6GRafOtR/wAs3phV42V9zJ6/yQazihYdKPwdP46D1womzve3nSo7CHfkbuzEftkv4Lbaf3rPT6mKbgpnuVKeaqOLxxBzpnRuDWt6xPTu2Be1WvjYkDpFsl/ocGIq5rEO7KuOMBJp6gNAuTc7BvJ6yltr6BzrI5t/75Gm7kTUi8Phq8SeIoelklO0Na5xJA3naVKl3MLc0iIiHNFc5bIWjLOWcYp6unkkgqGxNlYXEk2ADhe/bLy6yuoXQua17b2/vgdmMkRdTwZ+ll/SdSxrn/C2ADjxa2wAvzKkYWyPocaqicOP6mkqrmVD8HKeO/N6nyn2lnp+Hp+Nv9/QbuQ76HKuNskjLqepDQ9hNybABwJ77kuclfQbtUR7b/3yMtjkvqaTpbzZLgETKeA6tRNrEvG9jG2BI8JJt9xVZ2ew1lRI6V/BCVUSZW2QzDCMkYpmFnuiOMFjrkSSPsX+EF2131q1VGJ0lM7I91vIiNikelzpjfiWRKnc6GYAEtJuyRvhA2OC3clNiMS2sqfNDHtxuNC0hipzdSUVRRxyPDtdzmxna27WbCbi9iCFXMJbBQ1EkU6onK5JlzSNRWmcYjgeK4WwyzRTxxAgaznG1ybAbHKyw1NHKuSNUVSM5r26qdWF4ZiOLhxp2TS6lg7UcTq3va9z4CtppqWC29VGmGo93AuGVMFxHCo659RFNGw0rw0vJte4OzabFeTV1VLNJEkTkVc3gd2I5L5jjQtK99c+7nH9S7e4nvm8ytdpGNbSJlTxFK72iB0gzP8A0lVAPcGiTcHEDqt8K9DCY2LRx3TwOUz3Z1sbFo3x79P0THuN54v1cn1tHau+9tj5VSMdoujVN04O1J9PJmaVXTpIWMpNVzhd0u4kcI+S9jZRqOz3Q41aqlrFn0XO1sMgLjfrkkn+I8T9S8rHo71ytadadfYupmOfc71GYpXQQuc2hB1Wtbe8u2wcbbTc7grXhOERUkaPentc+RDmmVy2Q8kWjXGJWdIIANlwwvaHnj1V3XGqJH5Vca7l6pc/WTM41OUZRFJrmkDtWWJ17s4EtB6pHLiueJYZFXRXb2vBU8TaKVWuspZdPLmvNGQbtLZiCNxB6GxXm7MtVjJUXn/J0qlvZSxaUfgqfx0HrhQtne9vO0/YQ78jd2Yj9sl/BbbT+9Z6fUxTcFKzod7vr/qd/ucpO0nc4/X6GlP21NTxH4GXxb/VKqNGt52kx/ZMH0P/ALyh8W/1V9Dx7uLjzIPeH0AvmFz1j51zs9rMWnJNmidhJ5AahJ8i+qYairQMRPy/yeTJpLdTaHZ8wW5/bIvKfyVFdgdarl+7UnJOyx3UOb8Lr3tiiqI3yvNmtF7nZflyC5S4PWRMV72KiIZSZirZDNNOcJbVU7z1XROA+tr9vrBWvZVyLTPTxuRKtNbllyVpAw11PDTyv6GaNjWEPBDDq7Lh+7bZeZi2CVLpnSsTMinWKZuWyk5mbK9FnVsT3SHVj1tV8Tmm4fq3BNj8UFQaHEKnDLtyceZ0fGyUkstYHFl6BtNG57mNLiC+xPbG9tgCg19a6rk3jkt6G8ceRLFc0yfux3jI/WC9TZfva+hyqdGEFoH6lX/NF6JF6O1vFhzo/EvucO4anxT/AEKt4R3yP1JU3YUybQl3c/xLvWarntN3RPUg0naUic4wCrxmaJ2xslQxpI3gO6NpP9VPwx+SgjXyOcqfeKhKaPq5+UcTfRTGzZHdE88NYH9W777/ANwUTFqdtfRb2PimqG8Lt2+xO6eOpSfzS+iJebsmnbRTrWLwOyhr3UGWy9uxxa5gPLXkLb/1KSQ7zGEv4LcwjrQkBoXwhlbVvneLtgY0tuO/eSGn6wGuXobR1SwUyNava0NKZl3XNxXznVeB6PgUjNujmmzJP7pMr4nloDgxjXaxF+2NzvtsVlw/aCSmi3StzEeSBHrcpumSh/RsWH0+sX9HHK3XIsXW6EAkBe5s/Pv99Ja11v8AIj1DcqNQtmlH4Kn8dB64XmbO97ed5+wh35G7sxH7ZL+C22n96z0+pim4KVnQ93fX/U7/AHPUnaTucfr9DSn7amp4j8DL4t/qFVCj7w31Jj+yYNof/eUPi3+qvouPdxcebB7w+gV8vPU8D5zz5H0uKVLB1nTBo+8MA9K+q4Y5G0Ma+R5MyXksWL3nsR+Xg/v/ACXmu2ppUW2VTp0Ry6ktlPRnWYLWQ1MksLmRuJIbrXN2kbLjwqFX7RU89O6NrVup0jpnNdcvmaMuU2Z4ugmvsN2PbbWYbWuL/wBQq5QYhLRPzs/VCTJGj0splGLaJcRpbmF8c7fNu8huP6q50+0tNJ2/ZILqVU4FTdHiOVJRslpqjhvbrf8A1ePKvX/01bH4OQ5XcxTd8gZkOZqQTuAEzXFkgG7WAB1hyuCCvnmNUCUc+VvBdUPRgkzt1IzTH+7HeMj9cKXsx3tfQ0qewQegfqVf80XolXo7W/gNKPgpfM4dw1Pin+hVvCO+R+pJm7CmTaEu7n+Jd6zVc9pu6J6kCk7RG5m/fj/tUXrRKXQf7a1P+K/U1f70s2m7ASx0eIMHau/VykbwRtjd6R9wXlbNVqPa6nd4cPQ7VLLKjkIjSBjvZDQ4fOfhQZWyDk9rYgfLv+9T8Moui1ErfBdUOUz8zEJKsYXZZjtwe0nzyjRqiYw6/I3X3B6NA8g/a28f1R+79aFG2rauRim1H4ll0qy10VIw0pmEvStB6IOLtXVfe+qL2vZeXs4yF07klta3idqhXZfZMjq8dxuit0k9XHrbtcyNvbfbWte1x5VdW0dG9PZaikFXvTipK5/qJKqhwqSRxfK6OYuc43JOtFtJUTDmNjnnaxLJf6KbyrdrVL/pR+Dp/HQeuF4Gzve3kqo7CHfkbuzEftkv4Lbaf3rPT6mKbgpWdD3d9f8AU7/c9SdpO5x+v0NKftqaniPwMvi3+oVUKPvDfUmP7Jg2h/8AeUPi3+qvouPdxcebB7w+gV8vQ9U+ds6uDMWnJ2NE7CTyA6Mk/wBF9Uw264exE/L/ACeTIv3hs7s94Lc/tkXl/wDxUV2B1yqv3ak5J2WOOzvBfnkXlP5LT7Crvhqbb9hS9KuYcTwapi9zzujp5IrtDQLEg2J2g7drfKrFgNDTTQOSRiK5FIs8jmLdPEt2Tc3UmM00ZdMxtQ1oErXuDXawFi7ba4O+4Xi4nhM0MzsjfZ8LHeKZHNKvpjx2hqKdlMx7JKjpA7tSHajQNt3DdfYLL2NnKGojkdI/RLHGpe1Ush7dCFO6KjmkPVkmJb4dVrWk+UFRNq5GuqGInghvSIuW57dMn7sd4yP1wuGy/e19Daq7JB6B+pV/zReiVejtb+A50fBS+Zw7hqfFP9CreEd8j9STN2FMm0Jd3P8AEu9Zque03dE9SBSdojcz/vx/2qL1olLof9tb/wBV+pq/3pumP4WzGoJaZ/VkaRfke9d9xsV8+oqp1NUpIngp6L2Zm2PmSqimonOp33Do3kObwDh2pP8ATf8AUvqsT2SNR7fFDyFSy2NoyrhX6cwEUw6z2SBt/ja7i3+oCpNdUpT4sj14IpPjbmisZtkLMfYtV9JI09E4GOZtu2bt325tcN31qy4rQpW02VF14oRYn7t2pu0WZcOlj6YVUPRWvfpGjyi918/XC6tH5Mi3PR3rVS5h2kfNDMzVQfHf3PG0tjJ3uubufbhc28iv2DUC0kGV3FdVPOnkzqdmdf3dhHipvWiWKHvVR/2+im0q+y00XSj8FT+Og9cKvbO97eSp+wh35G7sxH7ZL+C22n96z0+pim4KVjQ73fX/AFO/3uUnaTucfr9DWn7amr1cfSxvYOs5rgPvBA9KptPIkcjXr4EtyKqaGb5H0b1eW6tlTJLE9jWuBDQ6+0WG8K1Ynj8FTTLE1q3UiRQq11zTVTiaZVmfRhWYvVz1LJoWslfcNcH3GwDbYeBXeh2ip4KdkStW6IQZKZXOuRfvPV/ziDyP/JSU2qpbdlTTojjh2hyvcO6IPI/8k61U35VMpSONLzLlenzJTNp5bh7ANSRo2scGgXF94NtoVXo8TfSVCyN4LxQkvizNsplGIaJ8Up3WZ0UzODg7VP8A8XDZ5VcIdo6N6Xeqp6kN1M9F0PXguiOuqHD3S9kMPEMOu8+AcAfCVwqtpaeNv3SXX5GzKZy9o2LDqGLDY2QRN1YmCzR4PzVGqah9RIsj+Kk5jEaliHz3gMuZKR1NG5rHl7Dd17dqb8F6GD1zKKdZHpdLGkzFelkI7RxlGfKbZxK9j+kLCNS+zVDwb3/mClY5ikVcrd0i6czWCJWFkxyidiVNNA0gOkjc0E7gSLXNl5NDMkE7ZHcEU6SNzNshStH2QanK1Q6oklie0xltma17kg32jwKwYxjUNZAjGIqanCGBzFup5cX0cVdfiLq9ssQiMrJNUh2tZpabbrX7VdqbaCCOkSBWrdEsaup1V9zTiVTl4k0zjPejeXMNT7pgkjj1mgSB4O1w2awt4LeRWzCsfjpod3KirytyIc1PmddC15Nwd+AUkVM9zXPZe5bexuSRvXjYpVMqqhZWaIp3iYrW2UrOetG7MceammeIqo9drh2jz8a46rvDtuvXwnH9w1IpUuicFOEtPm1QoseivF3v1SyJv8ZkBH9BcqwO2ho0bfMR0p38C3z6K2tovc8cjDWuka58r2kCwDhqNAuQ3avHbtMi1Cvei5LaId+jWaVnSjhb8FpcNpnkOfGyZpLb2O2Hddepg1Q2ofNK3gq3+SnGduVEQu2lH4On8dB64XjbO96eSZ+wh35G7sxH7ZL+C22n96z0+pim4KVjQ73fX/U7/c5SNpO5x+v0Nabtqa4qOTQlzIQWCXMBNQFi4CAIAs3UyE8QEMBAEAQBBYIAsCwWQEMhYMBZuOBkWnzrUf8ALN6YVedlfcyev8kGs4oWHSj8HT+Og9cKJs73p50qOwh35G7sxH7ZL+C22n97H6fUxTdlSs6Hu76/6nf7nKRtHrRx+v0NKbtqa2qOTgsGQgCAIAgCAIAgCAIAgCAIAgCAIAgCAIAiGDItPnWo/wCWb0wq9bK+5k9f5IFXxQsOlH4Kn8dB64UTZzvTzrP2EOzL7/0NiNbBN2kssz5owdz43Ws9p47RY8lK2kppHK2VqXRDWmVEuilTx/D6zR1VnEKb9ZRSuOuDu7Y6xY8jdtJ1SpFLUQ4rTbiXRyHJ7XROuajl/HKbMMIqIXXadjmnrMdxa4cCqdX0ElHJken6k2ORHoSagWOgWDIQBAEAQBAEAQBAEAQBAEAQBAEAQBLA8WM4tT4LE6omdqxN8rjwa0cSeSmUdHJVSJHGcnvRqXUyWlpKzSpVdPLeLDYSQLcBcEsaeLzYXPDYrrJLBg1Pu2avUhojpXXXgWjP8gxSSmooQX1TpY3BjdtmseC55PegDiVB2bgkSR0qpodalyWRpf8ANuWIcyxBjyWTMOtFK3rxu5jmN1xxVtVEVFR2qEYp2E4m/XfheIMaKgNsQdsczDs12X3jmN4VNxPC5KOTfwcCXHIj0yuKVi+F1mjKp92Ul5MPkNnNN7AcGPP3nVd/4+lTVMGLwbmbR6f26EdzHROunA1PL2OU+YYW1EJu07HNPWYeLXDn6VT66hkpJcj/AP0mRyI9LkmvPOwQBAEAQBAEAQBAEAQBAEAQBAEAQHixnFqfBYnVEztWJvlceDWjiTyU2jo5KmVI2HJ70Yl1Mlpaas0qVPTyXhwyE2AB3X3sadxeRa54K5vfT4NBkZq9SGiOmdrwLrjOKtwoRYdQRB1Q4WijbsDRxe88GjeSd68mgoJcQlWabgd3vSNMrS1ZLymzLjXSPd0tdLYyykbT/A0d6wcArqyNsbUazghE1XVS0rcFfzblmHMcQY4llQw60UrevG7mOY3XHFaqjXIrXcAU3CcTex78LxFjRUBtiDtjmYdmuy+8HiN4VNxPDJKN6TwcCVHIj0yuKTi2F1mjOp92Ul5MPkIDmm9rX2RvO3w6rl6dNUwYvBuZdHocHtdC66cDVMvY5T5hhbUQuu07HNPWYeLXDmqdXUMlJJkf+i8ycyRHJdCTUA6BYAQBAEAQBAEAQBAEAQBAEAQwqnixnFafBYnVE7tWJvlJ4NA4kqbR0clVIjI0/wAHN70Yl1MlpKau0pVPSy3hwyI2AHDm1p7554ngrm+SDBqfKzV6kNM0zvIuuM4qMLEWG0EQdVOGrFG3YGgb3uPBo3k8V5FBh8uITLNNwO73tiTK0tOS8psy410j3dLXSWMsxG08mtHesHAK7MjbG1GMTQiXvqWmy3BygCAr+bMsw5ljDXEsqGdtFK0dvG7mOY3XHFaK1HIrXaoCnYTiT2PfheIsaKgNsQdsczDs12X3jmN4VNxPDJKSTfwcP2JUciPTK4pGL4XWaM6n3ZSXkw+TYWm9rcGPP3nVcvUpqmDF6fdTaPQ4Oa6J104GqZexynzDCKiE3adhaesw8WuHNU6uoJKOTJJ/6TY5EehJrzzoEMhAEAQBAEAQBAEAQBAEB4cZxWnwWJ1RM7Vib5SeDQOJPJTaSkkqZEjYn+Dm96MS6mT0tNXaUqrpZLw4ZEbAA3tza0988gbTwVze+nwaDK3V6kJEdM4umM4q3C2xYdQRB1Q4asUbdgaBve4960byTvXkUGHy4hNvpl0O75EjblaWrJeUmZeY6R7ulr5dssxG0/wN+KwcArsyNsbUaxLIhEvfiWhbA5WQEAQBAV/NuWYcyxhjiWTMOtFK3rxu+MOY5jitXIjkyuS6KCm4Tib2PfheIsaKgNsRvjmYdmuy+8HiN4KpuJ4ZJRyb+BdCVFIj0yuKTi2F1mjOp92Un6zD5DZzTuA4RvP3nVd/4+lTVMOLwbmbR6f26HB6OiddOBqmXscpswwiohN2nY5p6zHcWuHAqn19BJSSqx/6E2ORHpck1AOgWDIQBAFkHWZmMdqFw1zwvtUlKWVzc6N0NVeh2KNYyFgyEAQBEMHhxnFqfBYnVEztWJvlceDWjiTyU2jo5KmTIxDm96MS6mTUtNWaUarp5LxYZEbADhzY08XkDaeCucj6fBoMjNXqQ0R0zvIuuM4qMLEWG0EQdUOFoo27A0De9x71o3knevIw+glxCXfTcDu97Y0ytLVkvKTMttdI93S10tjNMRtcfitHesHAK7MY2NqMYlkQiaqt1LQFuDlAEAQBAEAQFfzZliHMcQY4lk7DrRSt60buY5g7LjitVa1zcqpoCm4Vib2PfheIsaKgNsQdscrDs12X3jmN4VNxPDJKSTfwcP2JUciPTK4pWMYZWaM6n3ZSXkw+QgFp3AcI3n7zqu/8fTpqiDGId1Lo5Dg5ronXTganl/HKfMMLaiE3adjmnrMPFrhzVOrqGSkkVj/0XmTY5Eel0JNeedQgCALJhSEno5ny3De1OsC7hYkOafu2q70+MUjKPIvFEtYiOidmuTapTtdSWnALQyEAQweLGcVp8FidUTO1Ym+Ung1o4k8lNo6KSpk3bEOb3o1LqZLS01ZpUqellvDhsRsADcC+9rTuc8i1zwVze+DBoMjNXqQ0R0zr+BdcZxYYWIsNoIg6qcNWKNuwNA3vce9aN5J3ryaCgmr5VmmXQ7ue2NMrS1ZLymzLrXSPd0tfLYzSkbSfit+KwcArrGxsbUY1LIhE46lostwcoAgCAIAgCAIAgK/m3LEGZYwx5LKhh1opW9eN3McxuuOK1VqORWu1RQU3CcTfrvwvEWNFQG2IO2OZh2a7L7xzG8KmYnhklI/fwcP2JUciSJlcUnGMLrNGdT7tpbyYfIbODr2twjefLquXp01TDi8G6mSz0/tzirHRO04Eh79UXzM+fb/zUTqmnxDfpS8h79UXzM+fb/zTqmnxB0peQ9+qL5mfPt/5p1TT4g6UvIe/VF8zPn2/806pp8QdKXkc+/VD8zPn2/8ANZ6pp8QdKXkPfqh+Znz4/wCax1UT4g6UvI49+uL5mfPj/ms9U0+IOlLyHv1RfMz59v8AzWOqafEHSl5Aaao/mZ8+3/mspsmicJB0peRH0dNWaVKnppbxYbEbAA3A5ta6w1nnibbFLkkp8GgyM1epoiPlddeBdcZxUYWIsOoIg6ocLRRt2BoG97jwaN5J3rx6CglxCVZpl0O73pEmVpacl5TZlxjpHu6WulsZpSOtya0d6wcArsyNsbUYxNCIuq6lpW4OUAQBAEAQBAEAQBAEBX825ZhzLGGPJZOw60UrR28buY5jdccVq5EcmVyXRR5lIpMyT4HrUtfE8VDNmsxj3xyDg9pDTsPI7lUa3Z+RJc1PwUksnRUs47+zaj+Sf5l/sKH9h13mb76Mdm1H8k/zL/YT7DrvMb6Mdm1H8k/zL/YT7DrvMb6Mdm1H8k/zL/YT7DrvMb6Mdm1H8k/zL/YT7DrvMb6Mdm1H8k/zL/YT7DrvMb6Mdm1H8k/zL/YT7DrvMb6Mdm1H8k/zL/YT7DrvMb6Mdm1H8k/zL/YT7DrvMb6M89dm19e0U9FBI+qedVrTG9jRfe5zi0BrRvUil2fmWS8y6GrqhqJ7Jb8l5TZlxjpHu6Wuk2zSkbSeDWjvWDgFcY2NjbkalkIvHiWgLcHKAIAgCAID/9k=</thumbnail>
	    <fanart>data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxITEhUTEhMWFhUXGBgbGRgXGB0aIBoZHRgYHyEeGhodHSggHRsmHRgdIjEhJSkrLi4uFx8zODMtNygtLysBCgoKDg0OGxAQGy0lICYvLS0vLS0tLS0tLS0tLS0tLS0uLS0tLS0tLS0vLS0tLS0tLS0tLS0tLS0tLS0tLS0tLf/AABEIAL0BCwMBEQACEQEDEQH/xAAcAAACAgMBAQAAAAAAAAAAAAAFBgQHAAMIAgH/xABPEAACAQIDBAYFCAYEDgIDAAABAgMEEQAFIQYSMUEHEyJRYXEUMoGRoSMzQlJicoKxFUOSosHCJFNjshYXNERUc4OTo9HS4fDxNdMIJbP/xAAbAQACAwEBAQAAAAAAAAAAAAAABAIDBQYBB//EADYRAAEDAgQCCQQCAQUBAQAAAAEAAgMEEQUSITFBURMiMmFxgZGx0aHB4fAUQvEVIzNSckM0/9oADAMBAAIRAxEAPwCZXZqkZA4sTYKNST3ADUnwwIUWto6tk35itJF3y+uR9y43efrEHwOAmy9a0uNgLpakzWkgN4IzPL/Wy8Ae9Rb8gPM4qdKOC0YcOe7V5t7oLmmdTTfOyG31Roo9g4+ZucVFxdutJkMUIu0efFN/R/kcVPD+l65eyp/okR4yPyex8uz5F+SnFmjG3KzyJKyYRR7fuqDZvmctTM80zXdz7AOSqOSgaf8AfCbnFxuV1kEDIIxGzYft1DJx4rlaux2x/o9OamdflpF7Kn9Wh8OTtz7hp34chjyi53XJYtiHTO6Jh6o+p+OSH5nRrNG8TcGBHkeR9hsfZi5wuLLKikMbw4cEh7FbMCsrzBOSkUKvJPbTsoQN0NyuSNeNgbYpY3mtOsnJADOKbv8ACzLQeqGUwejDQEKokt9YdnRufrX+1iH8jXbRN/6C7Jcv63hp6qfluTAs1Rk1V1g4vSzNZ1+6x8rdvQ/Xxe17XbLGqKSWnNpBb29VFzvb19YJkaKUcVcFT568RpoRoeWJpZBY84Y6g4EKblw9OqoKX6LNvS/6pNWv4Nonm4wIQ3bbOfSqyWVT2AdyO3DcW4BHgTdvxYz5HZnEruMPp+gp2tO+58T+2QEy21BsRqCNCD3jxxCyac5oGqO7XZwmYUkc3CugsjEDWZOWg53Nx3HeFu0MOt67dd1yU4NHMTH2T+28kdyKgGSUvpE4D5jUL8nGdRAnj4955myjQEnx7hG3Tde0tO+vlu7sjc/bxKS6idpGZ3Ys7ElmPEk8zhO911zGNY0NaLALXgUk8dGtUJOvy+RrLUKWjP1ZVHEeNgG/2WGKd1jlWDjlNmYJhw0Pgdvr7p96Ps7eaJophaaFmjkHcykg+YuOOG1y6bcCFTvS7tD1swpEPYh1e3OQjh+FT72PdhOd9zl5LqcEpMjOmdudvD8qvsULdTpsLClNDPmk4ukAKwqfpynTT3hb/ab6uL4G7vPBYWMTl2WmZud/sPupeQRRVd5qWqMNe5LSRTk7krnU7p1t+G9gPUwwyVrtFiVOHzQDMRdvMffkmXL9sJaeQQV8TRPyJ9V/FGGjDyOl9bYsSKdqOuSQXVgcCFKwIWYELMCFmBCpaizUUOWiujRWqqmWRFdxfq0V3Wy/7u9uZbW4UDFcji0aJ6gpmzyEP2Auq6zbNpql9+eRpG+0dB5KNF9gGF7k7rbbGxmjBYKCcCkmfo+2VWtkeoqTuUNPrKx03yBfqwfKxa2tiBxYEXMaALlZVVM57hFHqSp21+0bVs28BuQoN2GPhur3kDTeNhfusBywrI/ObroqCibSx2/sdz9vAIFiCdVidF2yHWsKydfklPySn6bA+sfsqeHefLViGO/WKwcXxDIDBGdTueXd5q0s2W8Z8sNrmFXEo1PngQoOyNOBmdUo4TUUt/vK8Q/JvhiJG6uZIbt7iq9TgPLGaF9AO6+elNGQ6MVddVZSQQfAjUYkBqqJy3KQ4XCIttSKgBK+MTLycCzr46W18RY+eG2ykbrmZ8Oa43j07lqmyZgplophNGOKMQHXw5A+R3T54uBB2WVJE+M2cLIv0e5VVzR1FV1iUkTAxGom0sBowjXS53jYkkC6gC5BA8da2qIQ4vGUXPJesw2DlELzUNXDXCMXdIxuuB9ld5r6X0uCbaXOmF+iaeyVvf6nPG4CZhF0hvVXF76YiGph9Rdua6sbYbIkoIRm1et3I/osB0JJ1DsO88R9UdrUkWuJEbblZLWyV03Rt258u9L+bZnLUytNM287HXuA5BRyUchhMuLjcrrIIGQsDGDQKHjxXLMCFvoat4ZEljNnjYMvmDex8DwPgcANjcKuWNsjCx2xFlcFLKiV0VZF8zXRqx8JVUDXuJS2nej40mkEXC4GWN0Tyx24NkxbW56tHSvMbFrbsYP0nPAeXM+CnEZH5W3V1HTGomEY8/Bc8SyMzFmJLMSSTxJJuSfEk4z13TWhoAGwW/LaB55Y4Yxd5GCj+JPgBcnwBx6Bc2ChNK2KMyO2CYekeuQPDltOfkKQDf8Atzkak+IDG/2pH7sMSkNGULBw2J08rqiTj+/hKgwsuiTdlG3MgT0eujFXTm2kli624FWPEjiL69zDFzJy3fVY9Xg8UvWj6p+n48vRMOW0RsZsnqOuQatSytaRPBWbj3Df469s4ba8O2XNVFLLTutILex80w5DtujsYpwYpV0ZHBUg+IOuJJdOEMysLg3wIWzAhZgQubxmKKjUdUG9HMheN1GsTEm/L1bkm+vrNfQ6Rc0OFirYZnROzNQjNsjkhAcESQnVZE1Fjwvbh58PHC7mFq3KerZNpseS87L7PTZhUrTw6DjJJyjjvqT3nkBzPhciTG3VVZUhgyjdNm220EKomX0XZpINLj9a4OrE/SF7m/0mJbuxCV+Y2Gybw2lFO3pZO0du4fJSd6WMVZVp/wAkI7sllwqZh1lxCmrkaX+wD3nv5D2YmyLMdUnW4kIWdXtHb5V1QbQxIqoihVUAKoFgABYADkLYd2XJOcXEk7rxXbSIUIwLxVzmO0CKx88CEP2b2nEeYrIRoY5EPkd0/wAuBCThWgad2nuxn9GQu4Fa0i6hzVdziwMskpakOK1GoGJZSqTM0I7sJkMuYVYijZo4kG9PKum5HfhfhvNwAPcTYhTixjOKzqupDhkATRtvn6TslPTALSU/ZiUcGIFt/wDMC/Ik/SOF5ZM502W7hdD/AB487u0d+4cvlC9ms7NHUx1AvZTZwPpRn1h/EeIGIRuyuuma6Fs0DmO8vFMOW7I0j1VRmk5Ay5HMkcdtJZCbkAfSjD8F4EkLwUgvOyt6xXIRdNKRA3dA9qNoJa2cyyaLwjS+iL3eJPEnmfAABF7y83K7CjpGU0eRu/E8z+7IRiKbTz0b7G+lN6ROv9HQ9lT+tYcvFAePedO/F0MWbU7LFxXEegHRRnrHfuHz7LT0qZJ1FZ1ii0c43x3BxYOPyb8RwTNs6/NTwap6WDId26eXD4SZila6sLYKqNRRzUY1lhPX0/mDqo7rsSL/ANscNU7tMq5jHabK8TDjofEbfT2Sttttoax41F+riFrd7n1ifLRR5N34jN1jZWYSGwxl3E+yBRS3xQRZbzJA5WN0e0BggeuI+UkPU0wPMn1n8RofZG/fhmnZ/Yrn8cq7kQN4anx4BFs16Lo5I+shcpOdW3yWWRjqS3NWJ4kX8sSkhzajdK0OKupxkeLt+o+f3VVtnOTVFK+5URlDyPFW8VYaH8++2FHNLdCungqYp25ozf3Hih+PFettLUvG4eN2R14MpII9owA21Cg9jXtyuFwnOl2xgqlWLNYt4jRKmIbsiee7ra+p3dDYXU4ZZUcHLBq8EHagPkfsfn1R6mFZSKJqWT06k+tHrIoH1kHrW4dnW/FRhkEEXC56SN8bsrxY96adntr4KlRZhfux6oJjDjAhc5SxBhYjAhDcuapSoFPR9vrDbqjqrFjyH0Ta5LcLKSbgYEJ2zyWPK6Y5fSkGol7VXKvK49Re4WNgOS+LE4WmkA6rVv4XRGU9PLqBt3nn4D3VZVB1xU3ZaUxJctuW0LTSCNdL6kngqjiT/wCcxiYBJsEpNK2Jhc5P+X1cca9TTxySbnHq0Zzc823QdThoCwsudlldI4ucpP6Tk501QPOCT/px6q1rnzRip+Qm/wB0/wD04EJGzKoYufk5B5ow/hgQoENQVmjcqwA3r3U81I7u/Ahbci2Wrcwd/RISyBiDIxCoDe9t5uJtbQXOoxXkTpqrAALbtFsVX0FpKqD5G4BkRg6i5t2iNV9oGPci8/lEhB6bLmqJo4aa7ySMFVfE8yfqgakngATgyqH8gkaq1s9aLLKQZVStvSMN6rmHFmYep5EaW5KANSScUTyf1C2MHoc5/kSeXz5cPwkonCy6QmyMbGbM+nyM8p6uig1mkJ3QbC+4rd9tSeQPeRhmKP8AsVz2JVrnHootypm2W0npTrHCvV0sI3YYwN0WAtvFeRtoByGnM4qkkznuWjh1CKZl3do7n7fKXMVrRTNsNso1dN2rrAhHWN3/AGFP1jz7hrzF7I4857lnYjXilZp2jt8q+KanWNFRFCqoAVRoABwAw8BbQLjHOLiXONyUudI2SelUThReSL5RPEqDce1SR52xXMzM1PYZU9BUAnY6Hz+FQgOEV2yJ7NZuaSqinHBW7Y70OjD3G48QMSY7K66Wq6fp4XR89vHgtPStk4pMwZ0+YqR10ZHC7euAfvHe8A64be2+oXLUdRkuxyDbPwSVEipFHK4LAMY0Z90cz2QdbYqMRK0BiUcQJGpVzU2cBKmJJ6eSnhiQRwB0KgmwuQx0JsALcezfnhoCwsFzr3l7i525ViwyhgCpuDj1RWqvoYpkMcyK6HirC4/9+OPCAdCpxyPjdmYbHuVZbUdFpF5KFrj+pc6/gc8fJv2sLPp+LV0FJjd+rOPMfcfHoq2qqZ43KSIyOvFWFiPYcLEW0K6Bj2vbmYbhasCkp+TZzPSv1lPIUPMDUN4Mp0P/AJbHrXFuoVE9NFO3LIL+48CnCHO6CvINT/Qqv/SItEc/2gOnL6WoHBxhpk4PaXN1eDSR9aLrDlx/Pl6Jkio84QBV6mVRwkElgw5GxGmnLXzPHDCxTcKra2pCKScCE0ZTSjJ6Y1MwBzGqFo0OvUR/aHfzPebLwBOKpZMg71o4dQmqk17I3+EkSuWJZiSzEkk6kkm5JPeThFdmGgAAbKFLSs7BUUszGwA5nFjDwSFU0NGY7JsOUmmpxGpAllKqz8gzGw/Ct/z78OMblC5OqqDM+/DgmTa3aKXLnWgoLQRwqu826rM7MLkksCDe4JNrkk64omlcHWC2MLw2GWLpZRe+wv8ACA/4wcz/ANKP+6h/+vFXTP5+y0/9Jo/+n1PyvTdI2ZAazg+cUf8ABceiZ/NQdhNIBfL9Sl6p23rCxLOpP3B/DFwkcsx9FTg7H1QzMNsKuQbgZSW0FltcnTvxNpcd0hPDEwdVWN0hVLUggy6nYpDFCpfdJBd2LXLkanhveJck8sU1DzfKtbBKVhjMzhc3sL8EF2a2unpLofloG0eGQ3Ug8d299029h5jFbJS1aFZhsVSNrO5j780zZXlcSdbX5GFeUpummkI3ob6nqweR47t7Hdspt2cNh+Zt2rlpaR1PKGzjTmOPh+3VbGpLM2/vdZvNv79w2/c728DrvXve+EnNIOq7GnnjkYMmyn7N5FLmFQKeLsoO1LJbSNO/7x4KOevIEi2KO+pWbiVeIxkbumLbDPYerXL6EbtJDoSP1rg3uT9Jd7W/0jr3Y8lkv1RsvcLw8xf70vaP0/J+iUcUraRbZjIJa2cRR6Di78kTvPeeQHM+FyJMYXGwStXVspo87vIcz+7roDJ8ripolhhXdRR7SeZJ5knUnD7WhosFxE0z5nl7zqVNxJVLMCFz3tzkvolZJGBaNu3H9xidB90gr7BjPkbldZdxh1T09OHHcaHxHygGIJ5P9E0VZlQM0Qmky5t7cPEw25HlZR7TCMOQvuy3Jcji1Lkqc2wdr58fnzW7J8zoay0FKZ6GdhaJ98uhYAkKQWIH7pPAG9hj0Shxy7KEuGSwM6XRwG687C5vVzVUuWZgTMpEiuH1KMn0le19020PipFucWOcH5SrquCB9KJ4xY6J36P5WNPus29ukqG77Ei/ttfDCxE0YELMCELz3Z+mq03Z4w1vVYaMv3WGo8uB54i5jXbpinqpad14zb29FVG1HRvU093p7zxdwHyijxUet5rr4DCj4C3bVdLSYxFL1Zeqfp+PP1SPilbCzAhSoMxmRQqTSqo4KsjADyANhgueaqdDG43c0E+ATRshl0ccf6WrR8kh/osR4yycnA7gR2fIvwCk6L3BouVw9NTPqJBGz/A5paznNJamZ5pjd2PsUclXuUD/AJ8ScZ7nFxuV29PAyCMRs2H7dQjjxXq2+j7Yjq4fSZ1+WkXsKf1aHvHJ259w05nDcMdusVyeLV/Su6KM9Ub95+EM2tyglXTUcbEaH2HkcMLFQ/aVPT6Na8D+kQWiq1HO3CQDu1v5MRfsYWnZpmC3sFrMrugdsdvHl5+6RHlAwsAujdIGqDVVWmmJtakZ6nTRCZZMMALGe9EthqLr8yo4++eMn7qHfb91TixqQndonbpBquszGpa9wHCD8Cqp+IOE5Td5XWYYzJSsHPX1KXsVp5SKCulgkEsLtG68GX8jyI8DocegkG4UJYmStyPFwmPMq2LOSkQg3Mx4CWP1WUcWl7lUcb6jTdJvu4bY7pB1guVqoXUL7xO0PD991O2hrocvpzldE12/zqfgXcjVb/A9wsvG9q5ZLdRqcwyhMjv5M3kPv8JHwuuiUvKstlqJVhhXedzp3Acyx5KOJOPWguNgqppmQsL3nQK/9ldno6KARJq3F3tq7d/gOQHIe04fYwMFguIrKt9TIXu8hyCM4mlVmBCzAhIXS7kvW0oqFHbgNz4xtYN7jut5BsUTtu2/JbOC1PRzdGdne/D4VM4TXWpl6Pc4FNWpvfNy/JSA8LNwJ8mt7C2LInZXLOxSm6anNtxqPv8ARb8q2TeLOhSLcJHKsyt/YBg668zwjv8AWxaY/wDcFvFZsVeP4Ls29svmf26PUFeokzbNYrneYQU5UE7zWRN5QOILBG05A4uaLuJ8lkzOLIGRH/18Jt2GrIVhWEXV1AurAqRpzB1GLEkmvAhZgQswIXx3ABJIAGpJ0sPHAgC+ipXpKzyhqJLU0QaUHtVC9kG3IAfOfePDlfCUz2OOnquswqmqYm3kdYcG/u3h6pIxStlZgXqPbYbRGsmBUbkEfZhjGgVeFyBpvGw8hYctbJH5ykKCibSx2/sdz9vAIBitPKwui/ZDrnFXOvySH5NSPXcH1j9lT7yPDW+GO/WKwsXxDowYI9zueQ5eJVvSSADU4cXLpK2wrYQCbi+BCq6DacU1SZBbqpV6udSLgob2JH2ST7GYc8C9BINwgG0OXGCYpxQ9pD3qeGveOHsvzwo5uU2XSU9T07Mx34+KDVLWGBqJnWC9RTxOoHVgvwsBqT4AYYACwZXuDt079DmVn9LJI6BBFDNJ5aKmvskOJWsqiS7QoVWVJkkeQ8ZHZ/2mJ/jjNJubr6BGzIwM5AD0XiGJmZVUFmYgKBqSSbAAd5OBSJDQXHYLS6OziGNGaVm3VQDUte1rHge+/DnibGFxSlXVshjzXVgybmS03URsr5hOoM0o/VKeCr5cu83Y27IxfI/oxlbusSipXV0vTS9kfXu+fRIROFV062QQs7KiKWZiAqjUkngBgXjnBjS5xsAr22C2SWhiu1mnkA6xu4fUX7I7+Z17gHoo8g71xmI15qn6dkbD7nvTTi1ZyzAhZgQswIWuohV0ZHF1YFWB5gixHuOPCLr1ri0hw3C5vz3LGpqiWBuMbEA968VPtUg+3Gc5uU2XfU04nibIOPvx+qgEY8V6sPP85lkypa+H59E9FqGHrBSQN+41v2rju66/LDrX3ZfiuMqaURVfRnsk3Hgf2yF7X1TUVLl1BC266r6RKRY2Y3A4ixG80n7AxFxLGAK6nibV1TnOHV/bI9k2eyVdE80tvSKN47SABd+NyAVa2nC+g0uFOJQvLhqq8VomU0gybHhyVm0Eu9Grd4GLllKRgQhO0W0VPRx7872JvuoNWc9yr/E2A5nEHvDRqmaaklqHZYx58B4qmNrdtaitJU/JwX0iU8fFz9I+HAd3PCckpf4Lq6LDYqbXd3P45e6WsVrSWyngeRlSNS7sbKqi5J8BgAvoove1jS5xsAnil6LKpkVnmhjYi5Q3JXwJGl/LF4p3cVivx2FriGtJHPZIWKFto7svkXpBklkutNAjSTNe2iqW3AfrEDjyFz3XsjjznuWfiNcKWPTtHb5R/LunikVFQ0UsYUABY2RgoAsAL7ugw8BbRcW5xcS47lQc56YIJxaPrIx9tdf3ScerxL659HUEgS7xsSQbjQceIwIQTMJImB3ZEbyYH+OBCk5fX+k0wpd1nqIT8juqWLJ9UAa6AW9inkcQe3MEzS1Bhffgd1qrdl5IgGrHWEH6AIZvaRcA+A3vZjwNDd1bLUPmNmhRf0lHECtNGF73bUn/AM8fdgL+SGUvF5Tt0VSMtLm1YxuRCsaMfrEOT8SmPHGzCV7DGH1TGDa4S4BhFduimy1SsdXFI3CMs/7KMR+9u4shF3hZuKyhlK4c9Pqn6uqEoA1fOinMKhSsMZHzSfWfx4XPHgg+kcNSPDPFc7QUj6twaScg3+B3lVnU1DyO0kjFnYksx4knCJN9SuxYxrGhrRYBasCmrm6NdjPRlFTOvy7Dsqf1Sn+cjj3DTvu5DFl1O65LFcR6Y9FH2R9T8cvVPuL1jLMCFmBCzAhZgQswIVXdM2S/NVajh8nJ5alD77j8S4VqG/2XRYFU6uhPiPv+9yq3Cy6ROXRpWoZZaKb5qrQoR9sA2t3EqWF+8Li+B1nW5rFxqnzwiUbt9j8H7pK2ikqY6yRawHfU9WrEEKyx6ApfkfWt9rFkzSVn4TUMjNjurD2dhtlcSjVqyqBPfuRm/u3oh+3j2BtmqnGZukqLDYAD7/dW5Rx7qKO4DF6yUi7YdJMcO9FSWll4F+KJ5fXbwGnjywvJOBo1bVDg75bPl0by4n4VSV9bJNIZJnZ3bizH4DkB4DQYVJJNyuoiiZE3KwWC0Y8U0c2Z2WqKwkoNyJfXmfRVHO31mHcPaRibIy/ZJVlfFTDrankN/wAKyNn8tjhBjy5bsdJKxwCT4RgixH7ug0a98OsjDNlydXXS1LrvOnAcEaGxlO2si9Y59Z37RJ8SdTiaTVGZTlz1EqxR8TqWPBVHFj4D4kgc8ZrWlxsF3tTUsp4y93+TyVpU9THTwCmgXsAEEnUuTxLd5P8A24Y0GtDRYLiKid88hkfuUm7X5dTClqJPR4QwjazCJAQSLAggXvc4kqVV+yuWpNI4kW6ql+JGu8AOHtwIRyHKUV2SkSSSZ0ZVjW78edgL6aa3sMCEfyjolSBBPnFStOh4QoQ0jeFxcX8FDezEXPDd1dDTyTOyxi6IV+2dPSxmDKaVadDoZWG9I/ib39m8W8higzE9la8eEtj1lNzyHyq6zGqeRy8jF2PEsbn/ANeGAL17Wt0aLBQ5GsMSAVL3ZRdWlkcJp9nDvaNVVZ08FI0/4B9+CfRlkYQ3pKvNyBP2+6VJpAoucJgXXVSPDBcp12LyhKOEZtXA3I/osB0Lk6hyPG11vwA3uO7ZtoEbblcvM+TEJ+iZtz+6W84zSWpmaaZrux9ijkqjko/78ScKucXG5XTQQMgYI2DQft1Cx4rlZ3RfsZvbtbULpxhQ8+6Qj+7+13YZhi/sVzmL4ja8EZ/9H7fPorVw0ucWYELMCFmBCzAhZgQswIUHPMsWpp5YH4SKRfuPIjxBsfZiLm5hZWwTGGRsjeBXN9TTtG7RuLOjFWHcymx+IxnEW0K75jw9oc3Y6rzDKyMrobMpDKe5gbg+8YF65ocC12x0Vl7U51F1dPXPTpPSVahKiJgDuyqNCL6bwCsutvmlsRfDxk6ocuLbRf77oCbEbHn/AJ3WrLsoilMUuVVG+sIYijmNmUNu33WJv9EAb1xr6+JMe12ypqaWaB3+6PPgfNBNs9t6yZ2pZI3pVAs0Z0Zx3s3ND3Loe84Xmc7bgtrCKentn3d7eX3SjbC66JfUUkgAEkkAAC5JPAAczgUSQBcpzo9loKOMVObPuKfUpl1kkPcbG/sHC43iNRhhkNtXrDqcVc93RUouf+3x8lFUzSSvpjLD8lDSsN6iQAXi5M1vWIA3go7PZYWJAJvje12ywqumlhcDJrfW6snIqiN4VaO1iBwxYlERwISBlmywoqTd0Mz2MrDv5KPsr8Tc89K4o8g70/iFaaqS/wDUbD7+JQc4sSCWtt2eWA0sCtJNMyKqKLk2YMfZZSSeAAN8CFr2c6ORQxmXNatYA4HyERDSMBy3hfnod0N94Yi54bur4KaWc2jbf95ohNttHToYcrplpkPGRgGkfxJN9fFix8sLPqCeyugpcDY3rTG/cNvX/CS8xrXdi8js7nizEsT7TinVxuVruyQsysFh3IRI18WALOe65uoTAk2AJPcMWgLPlcAblGsiykLG9ZPpHHfcX68g5+QOnn5HFoFhcrNkeZXZWp82yfqstyuAjdJiMzjuZwp/OR8UVB2C1sCaG9JIe4fvooGw+zccytmFd2aKE6Kf1zg2tb6SBtLfSbs8jj1jA0ZnKNbVSVEvQQ/v7xUbaraGStnMr6KNI05Iv/UeJPPyAxQ95ebrcoqRlNHkG/E8z8ckGxBNp36ONjvS36+df6Oh0B/WsOX3Bz7+Hfa6GLNqdljYriHQN6OM9Y/QfP8AlXWBbDq5JfcCFmBCzAhZgQswIWYELMCFmBCprpeyXqqlahR2ZxZvCRQB8Vt+y2E522dfmuqwSpzxGI7t28D8H3SDihbid9hrVdLVZW5sZFMsJP0ZFt8N4I1h9vvwxAb3aVgYzEWOZUt4aH7fCRqSV0a/ajkQkaEqysDY6jUEHTFLhYrWge2aIE6gpz2lqGrMoiq5tZ6eo6rrLaujAaHv4r7UPecMXzR3KwzEKWvDI9iL25IHs5s9UVr7kCXA9ZzoqfePf4C5wuxhcdFtVNZFTNzSHXlxKeoaRMvhkbL4hV1SKd+ocdlAPW6tRxsNbKfNiRu4bEYjbcalczLWvrZRG85W32+VWNXUSzyGaeRpZW4s3d3ADQL3AWAwq55cukpqOOBtmhFdlc9eiqFmW5XhIo+kh4jz5jxA8ceMeWm6lWUramIxnfgeR/d1amWVC0k6dWb0dSN+BhwUnUp4cbgaaafRONAG4uFwz2OY4tduE8K19ceqKqwdK8bi0tIw+5IG/NVwsKnmF0DsAd/V48x/lCara+jYkhZk+8ikfusT8MSE7SlpMFqG7WPmvew2YqwzSpgO9PFAgjuuqqesJIBGtygJH2FxNzuqS1JxU9qhscugJF/BI087SMXdmdm4sxJJ8ycIXvqu4axrBlaLDktMjWGBDnZQhs8lzi0CyzJZMxTHl+yJKCSZwFIuFQgkjxbgPZfzxe2O+pWPPiAb1WDXvWuky1ZZTDEAka6yuOS+Z+kbaX8TyxcAAsp73SHUqFtHXekyR00PYiDLHGBwuSF3re3Tw8zirNmctLoOggJPaP07lY2e5OMzzJrt1dDRxIssl7DS77it3lWFz9Ea8xf1zbuudlVDUOZB0UfacfwgG2e0gqmSKBerpIezDGBYaC28Ry00A5DxJwrJJnPcukw2gFMy7u0d+7u+Ut4rWkmTYjZV66axusCEdY/8i/aPwGvcDZHHnPcs/EK5tLHp2jsPue73UzPdp8/o6qaOlpJPRI3Kwr6KWQRroCHRbkG19WJ1w8BbQLi3Oc9xc43JUOk6eqxCVqKOJmUkEKXiII4ght+xx6oo/QdPtI1utpJ1J5RlJNfC5S+BCdM16Rsspqh6WoqOrlTd3gY3IG8oYdoKRwYYEIhQ7Y5dNYRVtOxPBetUH9km/wAMCEaRwRcEEd4N8CF6wIWYELMCFmBCA7b5L6XRyRAXcDfj++uo9+q+THEJGZmkJygqf487X8Nj4H9uuesZ67pTMmzFqaeKdOMbBrd44MPapI9uPWnKbqmohE0TozxH+PqnPabZWGTMPSTOsNHUxicyG3Gw392+gvdWuebnQ8MNvjDzfguYpcQdSsMRbdwNgF6zZqaqpYDBdcspprOAD1kjnRWb6QBL2txPWg6cpBrS2w2Sr554pjLIOsRxTll2XvPGsaoKakA0hTQsP7Qjv5qO83LYsAAFgk5JHSOzPNymeko0jUKigAY9UFSXSNsx6HUb8a2glJKWGiNzT+I8NPo4RmZlPcuxwut/kRZXdpu/eOfz+Uo4qWonnYHMlmjbLZ23Vc71O/OOUXaw8zqBz7Q+lhiB9jlKwMaosw/kM3G/hwPymRNtfRx1FSQk0fZcE8xzHeCLEHmCMNrmVUWMxfRVhGBC3ZJmk9DUCppiN61mVvVdDxVvcCCOBGLo5cqyMQw4TDM3dNkcGX5prSkUdZxamkPYc216oj+UctVHHFjomu1akYMSnpT0dQLjnx/PmkfOqaWGQxyoUYcjz8QRoR4jFQYW7rSdVMmF2G4Q3ElQpuVV1TvrBTksZDYIeHeT9mwuSRyGuLI730WdXiPLcjVGc9qVp4vQ4jdjrPINN5jy/wC3IWGuuJSP4BVUFN/9XeXyoGxWRT11dFHCLCNhJJIeEag3BPe1xovM9wBII28UYhMOwE6ba7Qx7goKM2poz23vrM97kk813tb/AEjrwAxTNLm6o2WrhWHdEOmkHWOw5fk/RJuKFuIrs3kMtZOIYtObuRoi8ye89w5n2kSYwuNglauqZTR53eQ5n93XQGS5VFSwrDCtkUe0nmzHmxw+1oaLBcRPO+Z5kedSppOJKpcj7Nr6bnMJtcTVgkYHmpl32v8AhvgQumqrYnLZGDtRQb4YMGWMId4G4JK2J1HPAhc07fv6VnVSB9KpMQ/Cwjv+7gQrOzHoAgP+T1kieEiLJ8VKflgQjGx2zZ2eoq6oqHWX1WG4SN5UUhVII7LF3I0vxHlgQq5pNutoMzqGSjdgQC3VwhFVFBA9Z9eJHrNzwIU6p2s2oy/t1KO0YGpkhR0H3pIhp7WwITptV0sSZcaWKekDyy08csoWQp1bMSCoBVr23TxOBC8UPTxl7WEkNRH47qMB7Q9/hgQmGg6Vsnl0FWqnukR0+LLu/HAhVnt1RRJVGWndXgqLyxuhDKSWIcAjTRwdOVwMIzNyuXZ4VU9NTgHdunx+9yXcVLTTrQQfpDKJqW29PRt10PMle0d0d+hdbcBdO7DMRzMLVzWJxCCqbPbR2/jx+UR2eoepoEpiQZqyVJCg16uJChu3iSlvxG3qnFsLC0arPxKqbPKMuwFvFWtSR7qKO4DFqzluwIQzaPJY6uneCTgw7Lc1YcGHkfeLjniL2hwsr6aodTyiRvD6jkueMxoZIJXhlFnRt1h4948CLEHuIxnkEGxXdRStlYHs2K0I5BBBIIIII0II4EHkb48UyARYq2Mr6RqJokNXH8va0hEQYEjS97cwAbcr25YbbUC2q5afBJukPR2y8LlKlLU5HOsrCmroRFbfYEMFvfvdyfVPLB0Me6i3Fq0ODTYk9w+1lrFJkTmyZlNGf7WFre/q1HxxHoWf9k2MXqm9qIfX8rYuyVI+kOb0bnkGIQ+7rCfhjz+PyKmMdA7UZHn+EvbS7GzRaiSB9bgxOT5HVRbEmRPaUtV4jTzttY+Y/Kj0ucTheqzCEzxcnuC6+N73bz0bxPDF9r6ELID+jdmjco+b5Six9fTSiWH3Mvgw0/IHwxU6MjZaUWINcLP0P0TNBlv6JouumA9Pqh2VI1hi0OvjwJ8d1fok49JyC3FURRuq5C49kJLy3Lp6udaeAF5ZDxJ0He7tyUcSfzJAxBjblO1NQ2JtgrIzyrhy2m/RlE13OtVONCzEaqO48rfRFhqSSPJpLDKFPC6AyH+RL5Dn3+HJJGFl0ilZZl8lRKkMK7zubAfmSeQA1Jx6ASbBVTTMhYXvOgV/bJbOR0MAiTVjrI9tXb+CjgByHjcl+NgYLLiayrfUyZ3bcByH7ujeJpRCNsK7qKGqmHFIJWH3ght8bYELnPoLo+sziFuUaSuf92VHxcYELqGRwoJOgAJPkMCFx7kmXNmeYrFvbjVMrktbe3b7zk2uL8+YwIVkSdDWbU/+R16W8JJIT7lBHxwIVyZ1kS1VE9HKxs8W4X4neAFm14kMAfG2BC5lrMvzPIasON6JhcLKo3o5V5i5FmBsDunUWBsDY4EK4OjzpghrXSnq1EFQxCqQfk5G7hfVGJ4KSQeF7kDAhWNXZXBN89DFLpb5RFfTu7QOmBC5j6aoKeLNJIaeKOJY0jBWNAg3iu/ewAF7OPdgQrKyzoUoJ6SndzPFM0MbSFHBBcoC1wynS5PC2BCM7YbGJHlMcUN2NGu8pIF2X9Ze3f63moxTO27b8lq4RU9FUBp2dp58P3vVQ4SXYo5sXnXolZFKTZCdyT7jWuT5GzfhxON2VwKSxCn6eBzBvuPEftlZ+zeTJTV1Qh13iHiJ5RtwUdyqQUA7lHfjQXDJ3wIWYELMCFXvSvsx10XpcS/KRDtgfSj7/NePlfuGF547jMFt4PW9G/oXnQ7dx/Kp7Ci6pfcCEw9EJWWSuoX/AM5pyVJ5Olxp4/K3/Bh1ozNIXHVJ6GdsnL7JaaAcCLEcR3HCdyuuMbHa2UaphS3AYk0lLTRRgbIVLSKdQLHFzXkLHlpWO1stbPIvCRx+I/8APFgekn0rQn/ouyBUR83rifR4vmU5zSqdDbgwVhYfa103TeZdlbcpOKndNKI4+KB7X53JUzPPKe03AclUcFXwHxNzzwq0l5uV0ksbaaEMbw+venuhRcmy+MoL19agdpCB8lHYHdXy3gPFrk6ADFsj8gsN1mYfS/zJS+Tsj693ykgm+p1J4k8z44UXWAW0C+YF6pmWZpPTsXgkaNiLErbUXvY3HC+PQ4jZUzQRzDLILhMVL0kZinGVJPvxr/Ju4sE70g/BqV2wI8D83Rik6W6gfO00T/cZk/MNiYqDxCVfgEZ7LyPEX+FuzrpBoq6mkpamGpjSUAMYWQkAMDoWt3dx0viYqRySr8BmHZcD6j7Ib0e02S5fVNURVk12jMYWeMi12Q33lW1+zb2nExOw8Uo/CKtv9b+BCsTOM5gqaWoipKqAzSRSKnyqizMhAJ5jU92JB7TsUq+lnZ2mEeRVDUfR3ntDMtRTQ3dLlJI3ifiCpsrHXQnivPE0ujX+MXaSnHy9KzW4tLSso96bo92BCaqrpeemoaGeogR56nrGaONigWJXZVYX3jdhYgE62bhgQpP+ODJamIx1KyBWFmjlh3wf2d4YEKhM8WBq2QZcJOpMg6gG+/qRYD6XraLfW1r64ELselDBFD6tuje+9bX44ELk3byU1ec1IXi9SYl/CwjB/dGBC61jQAADgAAPIYEL6ygixFweIwIXOe1WTmkqpYPoqbp4xtqvnYaHxU4zntyusu8oqj+RA2Tjx8Rv8oTiKaVr7P5qZqKCoveWkbqpe8xGwDHv03Dc9z4ehfmauLxWm6GoNtjqPv8AVWPTShlDDmMWrNWzAhZgQsIwIVDdIezPodRdB8hLdo+5TzT2cR4EdxwhLHkOmy7LC63+RFZ3aG/f3/KVsVrSXjY7M/RsxpZ+QlVW1t2JOwxPkGJ9mG4zquWr47sumDpBofR6+oW1lZusXycb2ngGLD2YokbZ5C2sPnz0rHHhp6fiyTppLnHoFlVK/MUZotlpJoVljkQhgdGupBBII4G+o8MWiMkXCzZK5kbyxwOi27L7ES1lX1Mlkhjs88gYEBO4HkzWIF+ABPK2JtYRulamsa8ZY+KM7a7QrUOsUA3KSAbkKDQEAW37eQsO4eJOFpZM57lvYbQ/xo7u7R37u75SNmC3uMSZoq6wZ7hWXl9XBm9HTRyTrT1tOvVjrdFnUAC6tzJ3bkDUHe0tY4uezpBcLHoqw0MjmuFwfXxWmo6NswUXVIpR/ZyD4b4XFBgetpmNUrtyR4j4uhFXsrXR+vSTfhQuPel8QMbhuE2yvpn7SD297ITPGyGzqVPcwKn3HETpumWua7Vpv4aryDgUlmBCzAhZgQsIwIuttNUvHrG7ofsMV/IjANNlB8bH9oA+Iui9LthmEfq1cv4iH/vg4mJHjilX4dSv3jHlp7KVV7bTzqEqoaWpUf10IJHiCpFj4jExO9KvwSmdtcefyEJ6vKmN5Ms3bnUxVUg9ytvD2XGJipPEJR+AD+snqPz9k1bJZlkFJIJI6OZJRwkf5Xd+72zunxCg4kKhvFKvwKoHZIPn8hWHS7fZdJwqVU/bVk/vAD44mJmHilH4XVs/oT4a+yp7Z7oxqPT4KgVlFUItRHI5jluxAkDN2d21zY6X54mHA7FKvhkZ22keIXQ+JKpZgQq46Y8l34o6tR2ojuP9xjoT5Of3zheoZcZlu4HU5ZDCdjqPEfI9lUeFF1KbOjXNFiqupk1iqV6pweFzfdv7SV/2mLYXZXeKycYpulp8w3br5cfnyVq7KzMu/TSG7wsVuea8Vb2qQfbh5cemHAhZgQtU9SiC7uqj7RA/PHl1JrXO2CVNr80yypp3glq4LnVWVw5RxwNlufAjmCRzxVI5jhYlaNFDVwyiRkbvS1wqOIsSLg25jgfEeGEV2I1QCqS6kYZabFYMzczCE+9IGYelQUNZoWkhCSEfXXiP2+sHsxOUagpPDJSGui8/sfskfFa0U1bIV0joaSEb0zyfJrw9Ya3PJRulieQvi+I6WWNiTRnDhxTPtbXR0cH6Mpmux7VXKNDI5AuvloLjkoVddcVTyf1C0MGoP/u8f+R9/j1SKx0wsuiOy8ZPlTVM24LhRq7dy/8AM8B/2wwxubRYVZUCIF3HgnLaCghWnPYAVVsB3ADDY0XMucXG5UTa/JxQrRxQO8Uno6tKY2KEsbC53SPpK2F5pC0gBbeFULJ43OeONghlJtRmcQ+TrpvxsJf/AOgbFYnKdfgsR2VjbJ5pm9TSiVmglBZhaSHiF0+gyi97+7DEbs7brCrYP402RpW6qp2Pz+UUsne0Z6s/3CT+1j0xtO4UGVtQzsvPqULnyvLG0egrID3xtvD2Xc/3cQMDE2zGKtv9r+ICCvl2RuxSPNWiccROnA+JKop9hxA0w4FNMx+T+zAfC4+Vtj2CEutJmFHUeUlv7pfEDTu5ptmPRHtMI8LH4Uer6PMyT9QHHekiH4Eg/DEDC8cE0zF6R39reIP2ug9VkFXH85TTL49WxHvAI+OIljhuE0yrgf2Xj1CGMbGx0PccRTI11C+4ELMCFmBCzAhfCo7seIuplLmc8fzc8qfckZfyOJBxGxVT4In9poPkEYpdusxThVMR3OqN8St/jiYleOKUfhdI7+noSiE3STVyRPDPHBIjqVbsspsRbiGsD7MS6dxFiqBg0LHh8biCNeB+yTBila6+gkagkEcCOIPePHAvCAdCrM2g2knWkps0ptzeYCGoBUmzi9msCLdq41vcOndh3pCWZguPFHGysMMl7cPt9Er1HSBmT/5yVHciIvx3b/HCxmeeK32YVSAdi/iShNTntXJ69TO3gZXt7r2xAuceKZZSwM7LG+gQ9hc3Op7zrjxMDTQLMCF9wIsg8g44vCxnDgmzKKJpcpmj4tTsJlHdG92/hJ78Xu1YsSF2SrsOJt++aUJTYXxQNVsvOUXVm7PU65RQiqYA19YnyYI+ZhIB1vz1BPexUW7JOLXu6Nthus2kpzXT3d2Rv8eaTWYkkkkkkkkm5JPEk8zhNdYAALBa5jpj0bqEhs1R6PNJoriKQqCbkC2p9oxeCRssWWGOQ3eLqbS5rU1U0FNI+8s0scZG6vBnAOoAPAnFjHElZ1XTRRsu0Jq6UarrMxlHKNY0HsUMfi5xRMbvK3MHjy0rTzJP2+yU8VLTV77J1MFFldM1RKkSGMOWkYLrIS/Pie1wGH4hZgXD4jJnqnnvt6aJO2o6dKWO60UTVDfXe8aDxAI328rL54sSSC7OybR5hVQVLqYqdZEfdYCGNkuLjd9eQMt7E73HiMCEkdK+znoGZSKigRSESxC2m6xN1twsrBhbuA78CEy51t/lQgRKWgDSFF3lICRxsV1UAdp7Np9G/fgQnLo7yGapoxLKs9HKHYWQyQhl0Ksq3B3bG34cCEztkuYR/N10lh9cI/vLqT8cCEibWdJrUrdW7UdawNmQRk243vIGKA6WtYnvtjwgFSa9zeybKXklbDWQCeXIkRGvumJ90sPrABE04635YgYmHgmmYjVM2eff3Q6qlyAsVf0umYcbESAfsmT/AJ4qMUfNaUeI14Fy247x8WWtcjymXWDOI08J13P7xS3uxHoAdirhjcrf+SL0uPe63/4t6h9aeopZ170kN/dukfHHhp3cEwzHac9prh6FDqrYTMo73pmYd6MjfANf4YgYnjgmmYpSO/vbxB+EHqssnj+cglS3N42X4kYgWkbhNMnif2XA+YUMMO/EVdZfceoWYELMCE69HUiTrU5bMfk6mMlPsyKOI8bAN/shi+A7t5rCxqEhrahu7dPj6+6R1jZCyPoyMyN95SQfiMVPFjZadHL0sQcvcY3jZdT3DU+4YimSQ3U6InTbPVknqUs58erYD3kAYkGOPBLvrKdnae31+EWpuj3Mn/zfcHe8iD4BifhiQheeCWfi9I3+1/AH8Kb/AIsK3nJTA9xkb/68S/jv7lR/rlNyd6D5Vazod6w4nQeePG7KcwyuurX2SjSGvSBvm54GhI5Equ8L+xGH48O20suSLznzd91XGd5WY2lhPrRs6HzUkX+GEAS02XaSMbPCHDiL+qsKqpv0zS081K6GpgiEc8DMFYW+kt+RIJBOhB4gqRi+RhkALVi4fVtonOimGh4oFLsNmS8aR/YyN/dY4o6J/JbQxOkP9x6H4QjMshq4wd+lnXxMT294FsAY4HZEtZA5vVePVAJIHX1kYeakfmMWWSQe07EJj6KqTrc3puBEfWSN5LGwH77Li2JZmJO0AWZ/VdbVTyXvvyyEeW8bfC2FHG7iV1FKzJAxvID2UFIyxCrxYgDzJsPiceK4uDRmPDVWbtd0Q+nVyzGo6uARRqVF2feQbtkB7KKVCm+uu9pjTC+dudmJKQemXo+hy4U0tKH6pgY3LNvHrBqCT3st9AAPk+V8C8Vp9CO0PpWWojG8lMeqbxUC6Hy3bL5ocCEO/wDyA2e6+gWpUXema5tzjchW9x3W8AGwISJ0I7UZfSCo9MESOtnjmKbzkaKyKQC3HdIA43buwIRvaTpxkkbqcspyS2gkkG8xP2Il59xJP3cCF86Qtmq3MPRqqaeOkiami61KmR492YFy4WKxJOosLAnHhcBqVZFE+U5WAk9yW8vyvLKQhlRq+UcGmXqoQe8Rau/kxAPdhd1QP6rap8CkdrMbdw1Px7qZnW1FXVdmWU7n9WnYQDu3RxH3r4odI525W5T0FPB2G68zqf3wQQoO7ELposad14anU8Rj3MVWYGHgiGS7E1FWQYIGIv8AOHsqPHfPG3hc4sYXnZZtW2ji/wCQi/Lc/vimaSBMt+fzmdpl/wA3pZHex7mBNh+LcwyLt7RWDJkmNoI/P90XzINuM0qKlYYZt1WuEE6I5JAvYlVUi4B03jw464BK0my8kw6aOIyHgidXtNXWUVWXUdTIZWiZN3cIZd7m5YEEC4OlxY88TIB3CXjkew9V5HmfspD01Ky71Tkrw/6iYG3uZBiHQsPBNDE6pm0l/HX3CFz0ORnjPVU5+qwD28wqufjiBp28EyzHKgdoA+XwtX+CVFIbQZvTEngslkY+97n9nETTHgU0zHx/aP0P4U7LYaPKGapnqoqioCkQwQHeN2BFzzFxcbxAAG9xNhiTIww3JVFZiD6xvRRNIHFBMu21ijBYZXA8rEs0spBJZjcm3Vm2p+tjwyMveylFh9WWhucgchf8J3ps/r2SjdPR4o6kPokRupG7YXLEczy5YvYbtBCx6mN0crmONyCmdcmqW+crJT93dT+4oOJKhff8FYz848sn35Gb+8TgQva7I0YFupT9kYELnzKqXfqoV+2GPkva/lwjFqQF1+JnJE53d7pzzyUxGOoW94ZEk057rAke0C3tw8uQUPpWpRHWtKuqTokinkdN02/ZB/FhKZvXXW4VUA0tj/UkfcKvnY7wdSVYcGUkEeRGuPWkhQnYyXcJ62YaolgV1rapWUlTaoltccLjesdCMMsdcLnquLopCBspGc1leq29NlI+1ut/eU4mlkEbPqxBrOrfeRf5QMCEw9GOYytLX1kwW9PSndKqVvvktzJv8ziLjYEq2FhkkazmQEmKNBjNC+glGtjKTra+lT+1Vj5J2z8FxOMXeAk6+TJTPd3W9dPuuisaK4VLnSJs/wCnZfPTgXcrvR/6xO0o9pG6fBjgQqE6DdpPRcxWJzaKpAjbuD3vGfPeuv8AtDgQulswo0mikhkF0kRkYd6sCD8DgQudYujuhpGP6RrhIyk/IUg3mNjpvO2iXHEEDjxxW6VrU9T4dUT6tbYczoP3wRSPalKZSmW0sVIp0MluslYeMjX92tr6HC7qhx20W7T4JEzWU5j6D59kAq6mSVy8rtI5+k5LH3nl4YoJJ3WwyNsbcrBYdy04FNeooyzBVBZjwVQST5AanAvHODRcmwTVRbB1G51tXJHRwji8zC/7Nx7mIOLmwOO+iyajGYI9GdY923r8BY2e5RSaUtO9fMP1k3ZjB8FI1ty7P4sWZY2d6z3T11XoOq3u0/KD53tbmNZpLOY4/wCqgvGtu42O8w8GJHhiLpzwTNPgzRq/VBYaVV4DFBcSteOnZGLAKTDIyMrod1lIZSOTA3B9hGPFa5ocC07HRWRtfIJ4qKrF068xtIFJWzqOruCNTcSbvki40WOzNBXBVMPQyuj5FOlJsnSsqsyBzYatqfecSVCnLs3Sj9SvuwIWqXZWkbjEvuwIVUdKuSxU9XH1ahVaEcBzDvf4EYUqNHLqMDDXQuvuD7hJ4wut1WXksp/RmXsP1dW6nwDdcfzK4dgPUXG4w21W7vt7BWrCbqPLFyzF7wIWYEKg+j7LjJPK9tI4j+0zAD4BsJ046y6rHX5YQ3mfZTdoMzp0RkkkG9b1R2j7hw9uGi8Bc5HTSSatCgbRzelZNQ1Cg3gLQN3hR2RveNkQ/jxVKLgOWhhrix74jx+yQcVLUTh0cJUTPLT06bxIVyx0VOIJZrG19LAAk2NhocXRcVkYnlJbzRPaOmpomtUVwkYHVIBw8Ce1/LiZkaOKUZRzP2b66IA20NPF/k1Kt+Tyneb8yf3hiBl5JxmG/wDd3omTZ2rk/QlfUSW36idYlNrXQdXe37UmPJXf7a9w+Fv85rRsNfQfKT8JrsE7dENLv1+/bSOJ29pKqPgze7F0Au9Y+Nvy02XmR8q7cOrkVora2KFS8sixqPpOwUe848JA1KmyN8hysBJ7lRlWMlp6mSop4JKuVpWkUytuQxsWJsigAsATpvA8teeKHVAGy2KfA5X6ynKPUqLnm2VbVXEkxVD+rj7C+2xuw+8Thd0jnblbtPh1PBq1tzzOp+EAAxBPLMC8RLJshqao2p4Xcc24KPNzZfZe+JNY52wS89XDB/yOt3cfRH5tnaCi/wDkq0GT/R6btv5MbXAPiFHji4QAdorHlxmSQ5adnmfj/Kh1HSE8SmPKqKOlU6dbIBJKw7zyB+8XxMPYzZKuoqupOaV377IRFtPOz79XTw1Td8pckX4gbzMAPAADB07V6MHlbqHJmyHaCCpkEIySm3iCbq4XQeUX8cDTG82soTx1lMzP0ht4lSKCpyqo4Za4fXsRzne0NjZS63FxxtiZhYeCXbitWP7/AEHwvFZR5QtzJS5lTj626rgeN1aQD24gYWDmmY8XqzsWnyH4UGMbPX3vTKtgPodUbnw3hEB8R5jEOij5pn/U60iwjF/A/KOjMBX08sywmGlg6qGmQ8S3WRkk2uL3CaAmwHHjhhjgdtljVUL43AyG7jqVaOVgiJL9wxNKqVgQswIVV9N0OtK/hKp/4ZH8cK1I2K6PAHf8jfA+6rEYWXRJ/wBl5L5RP3xVcTDwDNCD+bYbpz1SuVx1tp2nm37lW3lz3jQ+AwwsRScCFmBC5hjrZUR0jkZFe2+FJXetewJGpHaOnDXGaCQu/lhY+xcASNroG62NsWhZrxY2Tz0Zp6RR5ll5sWKCeId7gWP7yRe/F/aYQsZx6Gqa87X19j9EkTR2wuDdbssZYU+7KEpkFY8N99qkLMRxEe7Hpf6tm/fbFz7iPRZNKGurxn8vG2iQ6g64pbstac3ctEh0xIJd5s0qx8yTqciy2HnKzznxB3mHwmX3YnObNAS2CNzTySd3ufwlLCq6ZPPRpn1LRLUS1D2ZtxURQWY23ibAcBqBc2GnHF0L2suSsXFqaapcxkY0FyTwUrPOlWd7rSxiFfrvZ38wPVX97HrqgnZV0+Bxt1lN+4aD59kiV9dLM+/NI8jd7km3l3DwGKSSdStqKJkQysAA7lHx4rF9VSSABcnQAaknwHPAvCbC5TRluwlU6dbOUpIQLtJOd2w7906j8W7i1sLndyy6jF6eLRvWPdt6/F1sfM8mo9Io3zGYfSbswg+0WI9j+eLQyNm+qznVddVaM6o7vnf2QjPdtMyqlKdd6PFawjpx1Yt4t6505XA8MeGfkpx4LcXedUVpzTU8EEOcU4Xrl3o54VtJGLDWRQPEXsOJsVNicWkBzRmWZG+Snmd0GoHoVoz7Y+SBBPAy1NKRdZotbL9sDh5i401twws+Jze8LoqLFIp+qeq7lz8D9ktjFS1E4dE//wAkn+rk/IYtg7aysZ//ACnxCW9oQjyhbC0aqvtN2J87vb2YlM459FRhNMx1Ndw3JP2UjLNqK+m+bqGZR9CUdatu7tdoD7pGPBO4Kc2DQv7OngrBqFjkmSGryyCScxJIzxEx6tcWYWJ4qeLHyw1kadwucbVSxEiN5smWiyaSQx9YiQwxaxwR+qp11JsN5tTrYcTpxOJAAaBLve55zONymhRbTHqivuBCzAhV900w3pIX+rMB7GR/4gYXqB1QtvAnWncObfuFTwwouqTvsI96LM07oVkA8VEh/lXDNMdwudx9v/G7xHsrZ2cl3qeM/ZGGlziJ4ELMCFy4FJIAFydABqSfAc8Zi+imwFypjbH1R7cidQnHel7On3eI9tsMMjcVz9XXQMd1Tfw+UV2HeCjzKmaOYydYxhkYLZLSCygH/WbnAnhhhrcqw6ioMxvayG7WZWIKuohtYLI26Pst2l/dYYSd1XELr6dwnp2P5j6jQqLsptNJl0zHd6ynlG7PEdd5dRvLfTeAJ0OhBIPIhiN/ArExCjcDnbuF92oyhEPX0x36aTVCNd2/0TztyF9eR1Gvj2ZdtlKlrOm6r+17paqr7thqToB3nHjd1bUuyxkq0+lFRHJS0q+rT0yKPC+lvdGvvxGoPWAV2BR2hc/mfYflJWKFtr7gQvmBCnZTlFRUtu08LyHmVGg82NlHtOPWtLtgqZqmKEXkcB7+m6ZJNlKSkAbNK1Izx6iHtyHu5Egfht9rF7YLauKx5caLjlp2X7z8flRzt9FB2crokgXgZ5u3KRzsLmx5i7MPDEs7GbBKupKyq1ld5fjZF8zyOphnirKyV6uIfOKx3h1bcWjQdlSPWsoF7W54ZWHqClvbHZ5aOotHYwSjrIWGoKHlfna9vIqeeEJWlrl2eGVDZ4QeI0Pz5rZsLkYq6tVcfIx/KSk8Nxfonl2jYeW93Y8iZmdZTxKq/jwEjc6D58veyJbR0X6WWXMqZ+tWMmMw27SRKTukLx1uXIP1jbhbDEzSRdqwsKnjjeY5Ra/H5SrkGdVVA5ekksCbtG3ajf7y34/aFj44qZMQtOswpkmrdCmlJMszPVWXL6znG5HVSHvU6C/lY8eyeOLDG1+rdCkoq6pozkmGZv1Hn8o5sxksWWyNPLURTVG4yxQwne4/SY8QNONgAL8TYYlFDlNyqcRxQVLBHG2wvxVXoxa7E3LEnXxN8Kudc3XSUsXRRBnIIrszQ9fV08VrhpFv90Heb90HAwXcAvKuXooHv5A/ATnHt5DFmtY0sbsgk6tWSxt1YCHsm1xvBjcHnww26YNNiuVpsMkqI87CPAqxcm2oo6qwhnRm+oey37DWPttibZGu2KWno54P+RpHfw9RojGJpVZgQswISh0rw72Wyn6rRN/xFX+bFM46i08Hdarb339iqMGEl2SduintVFRDylppB7Qyj8nOL6c9ayxcdbeBruR9x+FZPR/Pv0UR+yPyw4uUTJgQswIVeZTBMNKCiipVOnWyDrJSPfofMuMRaxrdgmJ6qac3kcT7eijbQbIswElTK8zjXtm4H3VHZX2AYkl0tZ3l4EJMY3WXVSOTDUH2EYEL10mgStS1qCy1VOp/EoB18bOBb7OE6gdYFdTgUuaJ0fI39f8ACRKiEMMUg2WtLEHiyIbLzmFHV1L05bdkW190MPXA99wOO7pqBh2Nwc1chXQmnmBHipx2QaLMKEAh6eaeJkkBuCm8GIJ4X3RoeY9tvA3K5WSVImpzzG6mdItSZMyqD9VlQeSoo/O59uFpTd5XRYUzLSM77n6pbxWn0z5TsNWTDfdRTxDUyTncsO/d9b3gDxxY2FzlnVGK08Ol8x5D5290VjosrpdVSTMZR3diEHz4Mvl1mGGwNG+qwqjGZ5NGdUd2/r8WQ7aLa3MR1dytNSKy78VOu78nvDeG/wCtfdv6u6PDF6yXOLjclD9utm46SsZUF0kVZFPfvaHXn2lY+3CU1w5dZg7Y304NtQbFBAMUrYAsr12EqFq8sjV9SgMTeaaD3pun24ehddgXFYpD0VS4cDr6/lI+b7RUlOzZfVQtV08RO60Zs8LX1RTvC4H3hb1dRovj3sccpV1LTVcTRNFpf6jwUWl2wy1//wBfTRSUkFTdJaiUjeN9At95rKbkbxNhciwuSPWBgFmqqqdVOeJJtben0QqWjrMkrAyHXkddyeO/Aj+HFT7CaA50brFa5ggroc0ehHqD8I9mWQxZlH6ZlgG+T8vTEhSjniVuQNePceI1uMevizdZiro8RdTnoanhsf3gvGQ7KCj3q3NFWKKMEJGzKWkciwsASOZsON9dAL49ijLTmco4lXRTM6KDUnjZGny5KPK6ioKqJZlNiv1pjbsnuG/ceAxdK6zCVl4dD0lUxp539NVVlsILuE49Ge7HNUVb+pS08kh8yD/Kr4upxd1+SxcbkywBn/Y+36EjURYgu5uzEsx7yTcn3nEJDcp2gjyQgKRbEE6mHJ9tq6msEnLqPoS9se8neA8iMTbK9uxWfPhtNNu2x5jT8fRPWTdLETWFVC0Z+vH218yNGHs3sXtqBxCx58CkGsTr9x0Px7J4ynO6apF4Jkk7wDqPNT2h7Ri9rw7YrHmp5YTaRpChbdQ7+X1Q7oXb9kb38MRl7BV2Huy1UZ7wuehhBdymvoun3cyhH11kX9wt/Li2E2eFmYw3NSO7iD9bfdWZ0fdmKSP+rlkT9l2X+GHlxqbMCFmBC+KoHDAhDc+jBjN8CFXFYgKsPPAhDqxOsyMb3GmqmVT3qxOnkOt/cGKKgdW62MEeW1OXmD8pHthJdYmbo+gWSaaJh2WhLHzRlt8HOGKc9ayw8cjBha/iD7j8KTFI8Uvoqt2ATNET+qkQ79171JFyvC+vM3cXLp1j2Wpc2ijrZFeGWQdvqmFmK9m53lPd/wC7YqfC1xutGlxSenZkbYjv4JX2tz+LJ5hTUNHF1pW/pEpMjWPGw0I/at4Y8ytj2CkJpq11pHm3Lh6KBsTmUtfXLHXSNOHDFd7QRsoJuqAbouNOF+GvfFkpLrFX1eHRxU/SNOo+t1aWc5VEkVlUC3hhhYqr7OqZXiYNwscCFF2p+VyrLahj21DQk/WVd5bk9/yV/wARwtUjQFdBgMhzvZwtf0P5SXhVdKj+Q7UT0lNURRGxlZLNfVCVfeK+JCgX5WvibZC0EBI1NDHPMx7+AOnPa3ul+2IJ4rRJRCRlThvMq3te1yBe3txNhN0jWRtLCSOCs/ZBRWCbKKm8iQRq8MxPbTXdA8bcvDThazrmBwsVyNPVPgk6RnpwI5Ku5Ymhlbq5GR0Zl30JQ6MRxBuL24XwiHFp0XYvp4p2gubvr6rXUM8jBpZJJWHAyOzkeRYnHpe47ryGihiN2hE5M9nalWjZrxK4db8VsGG6D9W7XtyIx5nOXKptpI2zdMBra358UNtiKZTxs5TD9EVXfPURwsR9QdWbe0Ow/FhqnHVK5fHJD07ByF/r+F42r2DjpKcTxTMVNuw6gnX7YI09mISxZdbpzDcTdM4ROaPEfCSsULcWYELMeLxfUYghgSCOBBsR5EajAggEWKY6PbmuSNonl66NlKlZRvGxBBs+jXseZOLRK4Cyz5MLp3uD2jKRrp8bJaAxUtG6ObEyFcwpSP61R+1cH4HFkfbCTxEXpZPBW7smN2prFHDr3P7R3j8TjQXDJrwIWYEL/9k=</fanart>
</dir>


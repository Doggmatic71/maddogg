# -*- coding: utf-8 -*-
###----------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Addon: Stormy's YouTube Experience
# Author: John Doh
# Many thanks to Total Revolution for providing the template/base code used for this addon!!!
###----------------------------------------------------------------

import os           ### Access operating system commands
import xbmc         ### The base xbmc functions; Pretty much every add-on is going to need at least one function from here
import xbmcaddon    ### Pull addon specific information such as settings, id, fanart etc.
import xbmcplugin   ### Contains functions required for creating directory structure style add-ons (plugins)

from koding import route, Addon_Setting, Add_Dir, OK_Dialog
from koding import Open_Settings, Run

debug        = Addon_Setting(setting='debug')       ### Grab the setting of our debug mode in add-on settings
addon_id     = xbmcaddon.Addon().getAddonInfo('id') ### Grab our add-on id

### Set the base plugin URL you want your addon to hook into:
BASE  = "plugin://plugin.video.youtube/playlist/"
BASE2 = "plugin://plugin.video.youtube/channel/"  #Stormy's Learning Experience channel

### Set the ID for each YouTube "Playlist" you want to display in your addon:
YOUTUBE_CHANNEL_ID_1 = "PLtSAyvkX2MIeoZkIXWOJV52FIikzs8Grq"		#Instructional Kodi
YOUTUBE_CHANNEL_ID_2 = "PLtSAyvkX2MId1OZYOMNR_Td1WhiK3g72z" 	#Building off Grid
YOUTUBE_CHANNEL_ID_3 = "PLtSAyvkX2MIeC8GOeq-BZ4Y8prwi3Ntuo" 	#Living off the grid
YOUTUBE_CHANNEL_ID_4 = "PLIJlDpPRZD67oHmw1cgD1mudkml73Kuaq" 	#Mod your Silvo Kodi Skin
YOUTUBE_CHANNEL_ID_5 = "PLIJlDpPRZD67tbL-F2CG82cgPKSwYhGcD" 	#Mod your Xonfluence Kodi Skin
YOUTUBE_CHANNEL_ID_6 = "PLIJlDpPRZD67bcOIT2Ce8CzNBap-G8NaB" 	#Python Programming (Basics)
YOUTUBE_CHANNEL_ID_7 = "PLIJlDpPRZD65RfuS09jY_I_faR3oy2wuJ" 	#Python Koding
YOUTUBE_CHANNEL_ID_8 = "UC2XFD3s8EBsrBBhM8NiXGzg" 	#Stormy's Learning Experience

@route(mode='main_menu')
def Main_Menu():
    Add_Dir( 
        name="Instructional Kodi", url=BASE+YOUTUBE_CHANNEL_ID_1+"/", folder=True,
        icon="https://i.imgur.com/smsalfr.jpg")

    Add_Dir( 
        name="Build off Grid", url=BASE+YOUTUBE_CHANNEL_ID_2+"/", folder=True,
        icon="https://i.imgur.com/BKP87h2.jpg")

    Add_Dir( 
        name="Living off grid", url=BASE+YOUTUBE_CHANNEL_ID_3+"/", folder=True,
        icon="https://i.imgur.com/BKP87h2.jpg")

    Add_Dir( 
        name="Mod your Silvo Kodi Skin", url=BASE+YOUTUBE_CHANNEL_ID_4+"/", folder=True,
        icon="https://i.imgur.com/pqpWw80.jpg")

    Add_Dir( 
        name="Mod your Xonfluence Kodi SKIN", url=BASE+YOUTUBE_CHANNEL_ID_5+"/", folder=True,
        icon="https://i.imgur.com/5U4Ar8u.jpg")

    Add_Dir( 
        name="Python Programming (Basics)", url=BASE+YOUTUBE_CHANNEL_ID_6+"/", folder=True,
        icon="https://i.imgur.com/VH7s28L.png")		
		
    Add_Dir( 
        name="Python Koding", url=BASE+YOUTUBE_CHANNEL_ID_7+"/", folder=True,
        icon="https://i.imgur.com/VH7s28L.png")
		
    Add_Dir( 
        name="Stormy's Learning Experience", url=BASE2+YOUTUBE_CHANNEL_ID_8+"/", folder=True,
        icon="https://i.imgur.com/Kc3v0nm.jpg")

@route(mode='koding_settings')
def Koding_Settings():
    Open_Settings()


@route(mode='simple_dialog', args=['title','msg'])
def Simple_Dialog(title,msg):
    OK_Dialog(title, msg)


if __name__ == "__main__":
    Run(default='main_menu')
    xbmcplugin.endOfDirectory(int(sys.argv[1]))